#!/usr/bin/env bash
# setup.sh — Cài đặt toàn bộ thư viện & công cụ cho Sofia Scan (Debian/Ubuntu)
# Chạy: bash setup.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

log()  { echo -e "\033[1;34m[+]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[OK]\033[0m $*"; }
warn() { echo -e "\033[1;33m[!]\033[0m $*"; }

# ─── 1. Hệ thống ─────────────────────────────────────────────
log "Cập nhật apt cache..."
sudo apt-get update -qq

log "Cài package hệ thống: python3/pip3, masscan, zmap, bind9-dnsutils (dig), openssl, curl, git, unzip, build-essential..."
sudo apt-get install -y -qq python3 python3-pip python3-venv python3-dev \
    masscan zmap bind9-dnsutils openssl curl git unzip build-essential libpcap0.8 libpcap-dev

# ─── Zmap (engine stage 1 — thay thế masscan) ──────────────────────
# Đã thử cài chung ở trên; nếu repo không có zmap (vd. distro lạ),
# thử cài riêng rồi kiểm tra lại:
if ! command -v zmap >/dev/null 2>&1; then
    log "zmap chưa có — thử cài riêng..."
    sudo apt-get install -y -qq zmap \
        || warn "Không cài được zmap qua apt — scanner sẽ tự dùng masscan (engine auto)"
fi
if command -v zmap >/dev/null 2>&1; then
    ok "zmap: $(command -v zmap)"
else
    warn "zmap THIẾU — stage 1 sẽ fallback về masscan (scanner.engine: auto)"
fi

# NodeJS + npx: NodeSource nodejs đã chứa sẵn npm+npx, cài thêm gói 'npm'
# của Ubuntu sẽ xung đột → thử cả hai, lỗi thì chỉ cài nodejs.
if command -v node >/dev/null 2>&1 && command -v npx >/dev/null 2>&1; then
    ok "NodeJS đã có: $(node -v) (npx: $(command -v npx))"
else
    log "Cài NodeJS + npm (npx)..."
    sudo apt-get install -y -qq nodejs npm || sudo apt-get install -y -qq nodejs
fi

# ─── 2. Python libraries (requirements.txt) ──────────────────
# Fallback --break-system-packages cho Ubuntu/Debian mới (PEP 668)
pip_install() {
    sudo pip3 install "$@" 2>/dev/null || sudo pip3 install --break-system-packages "$@"
}
log "Cài Python dependencies: requests, pyyaml, rich, sh, pytricia..."
pip_install -r requirements.txt

# pytest chỉ cần cho tests
if ! python3 -c "import pytest" >/dev/null 2>&1; then
    log "Cài pytest (cho tests)..."
    pip_install pytest
fi

# ─── 3. Công cụ ProjectDiscovery: httpx & nuclei (GitHub Releases) ───
# Tải binary prebuilt từ GitHub Releases — không cần Go.
PD_BIN_DIR="/usr/local/bin"
case "$(uname -m)" in
    x86_64)  PD_ARCH="amd64" ;;
    aarch64) PD_ARCH="arm64" ;;
    *)       warn "Kiến trúc không hỗ trợ: $(uname -m)"; exit 1 ;;
esac

pd_latest_tag() {
    curl -fsSL "https://api.github.com/repos/projectdiscovery/$1/releases/latest" \
        | grep -oP '"tag_name":\s*"\K[^"]+' | head -n1
}

pd_install() {
    local repo="$1" bin="$2" ver_fallback="$3" tag ver url
    if command -v "$bin" >/dev/null 2>&1; then
        ok "$bin đã có: $(command -v "$bin")"
        return 0
    fi
    tag="$(pd_latest_tag "$repo" || true)"
    [ -n "$tag" ] || { warn "Không lấy được bản mới nhất của $bin từ GitHub API — dùng bản ${ver_fallback}"; tag="$ver_fallback"; }
    ver="${tag#v}"
    url="https://github.com/projectdiscovery/${repo}/releases/download/${tag}/${bin}_${ver}_linux_${PD_ARCH}.zip"
    log "Cài $bin ${tag} từ GitHub Releases..."
    curl -fsSL -o "/tmp/${bin}.zip" "$url"
    sudo unzip -o -j "/tmp/${bin}.zip" "$bin" -d "/tmp/${bin}_pd"
    sudo mv "/tmp/${bin}_pd/$bin" "$PD_BIN_DIR/$bin"
    sudo chmod +x "$PD_BIN_DIR/$bin"
    rm -rf "/tmp/${bin}.zip" "/tmp/${bin}_pd"
    ok "$bin ${tag} đã cài ($("$bin" -version 2>&1 | grep -i 'version' | tail -1))"
}

pd_install "httpx"  "httpx"  "v1.11.0"
pd_install "nuclei" "nuclei" "v3.11.1"

# ─── 4. Nuclei templates ─────────────────────────────────────
log "Cập nhật nuclei templates..."
nuclei -update-templates -silent 2>/dev/null || warn "Không tải được templates, nuclei sẽ tự tải khi chạy lần đầu"

# ─── 5. Kiểm tra tổng hợp ────────────────────────────────────
echo ""
log "Kiểm tra tất cả công cụ cần thiết:"
MISSING=0
for b in python3 pip3 node npx masscan zmap httpx nuclei dig openssl; do
    if command -v "$b" >/dev/null 2>&1; then
        ok "$b: $(command -v "$b")"
    else
        warn "$b: THIẾU"
        MISSING=1
    fi
done
for m in requests yaml rich sh pytricia; do
    if python3 -c "import $m" >/dev/null 2>&1; then
        ok "python module '$m': OK"
    else
        warn "python module '$m': THIẾU"
        MISSING=1
    fi
done

echo ""
if [ "$MISSING" -eq 0 ]; then
    ok "✅ Đầy đủ! Chạy: sudo python3 main.py --countries SG"
else
    warn "⚠ Một số thành phần còn thiếu — xem log phía trên"
    exit 1
fi








