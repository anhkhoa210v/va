"""Webhook thông báo — chống spam.

Vấn đề cũ: gửi 2 tin nhắn cho MỖI CIDR ("Đang quét..." / "...hoàn tất").
Với hàng trăm nghìn CIDR → hàng trăm nghìn tin, spam(channel) + rate-limit 429.

Chiến lược mới (batch + chỉ báo cáo khi có nội dung):
  - Bỏ tin nhắn "Đang quét" per-CIDR.
  - Kết quả per-CIDR CHỈ chứa domain/vuln mới được buffer; khi buffer đủ
    `batch_size` phần tử hoặc hết `flush_interval` giây → gộp 1 tin nhắn.
  - CIDR 0 domain / 0 finding → chỉ cộng vào bộ đếm; tổng kết được báo
    trong periodic summary (mỗi `summary_interval` giây) và tin cuối cùng.
  - Finding (nuclei) → gửi NGAY riêng từng tin (ưu tiên, không batch).
  - flush cuối tự động via atexit khi chương trình kết thúc.
  - 429/rate-limit: tôn trọng Retry-After, backoff; không drop tin.
"""
import atexit
import os
import threading
import time

import requests

from utils.logger import warn

_cfg = {"type": "generic", "url": ""}

# ── Anti-spam settings (có thể ghi đè qua config `webhook:`) ─────────
DEFAULTS = {
    "batch_size": 10,          # số CIDR buffer trước khi gộp gửi
    "flush_interval": 300,     # giây — gửi tối thiểu mỗi 5 phút nếu có buffer
    "summary_interval": 1800,  # giây — định kỳ báo tổng quan tiến độ (0 = tắt)
    "quiet": True,             # True = không báo CIDR 0 domain
}

_warned_missing_url = False
_lock = threading.Lock()

_pending = []          # các dòng kết quả chờ gộp
_stats = {"cidrs": 0, "domains": 0, "findings": 0, "empty": 0}
_last_flush = 0.0
_last_summary = time.time()
_started = False


def configure(cfg):
    """Nạp cấu hình webhook (dict con `webhook` của config.yaml).

    URL ưu tiên: biến môi trường SOFIA_WEBHOOK_URL > config.yaml.
    """
    cfg = cfg or {}
    _cfg["type"] = cfg.get("type", "generic")
    _cfg["url"] = os.environ.get("SOFIA_WEBHOOK_URL") or cfg.get("url") or ""
    for key in DEFAULTS:
        _cfg[key] = cfg.get(key, DEFAULTS[key])
    atexit.register(_flush_final)


def is_active():
    return bool(_cfg.get("url"))


def _payload(text):
    kind = _cfg.get("type", "generic")
    if kind == "discord":
        return {"content": text[:2000], "username": "SofiaScan"}
    if kind == "slack":
        return {"text": text[:39000]}
    return {"text": text[:39000]}


def _post(url, payload):
    """POST với xử lý rate-limit (Retry-After). Trả về True nếu thành công."""
    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.status_code == 429:
            wait = float(resp.headers.get("Retry-After", 5) or 5)
            warn(f"[webhook] 429 rate-limit — chờ {wait}s")
            time.sleep(min(wait, 60))
            resp = requests.post(url, json=payload, timeout=10)
        return resp.status_code in (200, 204)
    except requests.RequestException as exc:
        warn(f"[webhook] lỗi gửi: {exc}")
        return False


def send_message(text):
    """Gửi tin nhắn; trả về True nếu HTTP 200/204. Không bao giờ raise."""
    if not is_active():
        global _warned_missing_url
        if not _warned_missing_url:
            warn("[webhook] chưa có URL — đặt `webhook.url` trong config.yaml "
                 "hoặc export SOFIA_WEBHOOK_URL để nhận báo cáo")
            _warned_missing_url = True
        return False
    return _post(_cfg["url"], _payload(text))


# ─────────────────────────── Batching ────────────────────────────────

def scan_start(cidr, country):
    """No-op — đã bỏ tin 'Đang quét' để tránh spam."""


def scan_done(cidr, country, n_domains, n_findings=0):
    """Buffer kết quả 1 CIDR; gửi gộp khi đủ điều kiện."""
    with _lock:
        _stats["cidrs"] += 1
        _stats["domains"] += n_domains
        _stats["findings"] += n_findings

        has_content = bool(n_domains or n_findings)
        if not has_content:
            _stats["empty"] += 1
            if _cfg.get("quiet", True):
                _maybe_flush(force=False)
                return
            _pending.append(f"• {cidr} ({country}): trống")

        if n_findings:
            _pending.append(f"🚨 {cidr} ({country}): {n_findings} CVE — {n_domains} domain")
        elif n_domains:
            _pending.append(f"• {cidr} ({country}): {n_domains} domain")
        _maybe_flush(force=False)


def _maybe_flush(force=False):
    """Gọi với _lock đang giữ. Gửi gộp nếu đủ batch/hết interval/force."""
    global _last_flush
    now = time.time()
    size_ok = len(_pending) >= _cfg["batch_size"]
    time_ok = (now - _last_flush) >= _cfg["flush_interval"] and _pending
    if not (force or size_ok or time_ok):
        _maybe_summary(now)
        return
    if not _pending and not force:
        return

    parts = list(_pending)
    total = _stats["cidrs"]
    header = (f"📊 SofiaScan — {len(parts)} CIDR mới "
              f"(tổng {total} dải: {_stats['domains']} domain, "
              f"{_stats['findings']} CVE)")
    if _stats["empty"] and not parts:
        header += f"\n{_stats['empty']} dải gần nhất: trống, không có web/Magento"
    text = header + "\n" + "\n".join(parts[:30])
    if len(parts) > 30:
        text += f"\n... và {len(parts) - 30} dòng nữa"

    _pending.clear()
    _last_flush = now
    send_message(text)


def _maybe_summary(now):
    """Định kỳ báo tổng quan — kể cả khi không có gì mới (biết tiến trình sống)."""
    global _last_summary
    interval = _cfg.get("summary_interval", 0)
    if not interval or _pending:
        return
    if now - _last_summary < interval:
        return
    _last_summary = now
    s = _stats
    send_message(
        f"💓 SofiaScan đang chạy — đã quét {s['cidrs']} CIDR: "
        f"{s['domains']} domain, {s['findings']} CVE "
        f"({s['empty']} dải trống)"
    )


def flush():
    """Ép gửi buffer hiện có (gọi từ pipeline nếu cần)."""
    with _lock:
        _maybe_flush(force=True)


def _flush_final():
    """atexit: gửi nốt buffer + tổng kết cuối."""
    with _lock:
        if not is_active():
            return
        s = _stats
        tail = list(_pending)
        _pending.clear()
        if s["cidrs"]:
            text = (f"🏁 SofiaScan KẾT THÚC — tổng {s['cidrs']} CIDR: "
                    f"{s['domains']} domain, {s['findings']} CVE "
                    f"({s['empty']} dải trống)")
            if tail:
                text += "\n" + "\n".join(tail[:30])
                if len(tail) > 30:
                    text += f"\n... và {len(tail) - 30} dòng nữa"
            send_message(text)
        elif tail:
            send_message("\n".join(tail[:30]))

