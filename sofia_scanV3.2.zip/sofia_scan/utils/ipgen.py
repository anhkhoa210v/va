"""Tự sinh dải IPv4 để quét stage 1 — thay vì lấy CIDR từ RIR.

Bật bằng `scanner.generate_ipv4.enabled: true` hoặc CLI `--generate-ipv4`.
Các chunk sinh ra được đẩy vào pipeline như CIDR bình thường (webhook +
resume theo từng chunk) và quét đúng `scanner.ports` (mặc định 80,443,8080).

Các lựa chọn (block `scanner.generate_ipv4`):
  - cidr       : dải gốc, mặc định "0.0.0.0/0" (toàn bộ IPv4)
  - split_to   : chia thành chunk /N — mặc định 16 → 65.536 chunk /16
  - shuffle    : xáo thứ tự chunk (mặc định true) — tránh quét cụm 1 vùng
  - seed       : 0 = ngẫu nhiên mỗi lần; >0 = tái lập thứ tự xáo
  - max_chunks : 0 = tất cả; >0 = giới hạn số chunk (test/chạy thử)
Lọc `paths.exclude` (gov/mil...) giống RIR — dùng chung ExcludeIndex.
"""
import ipaddress
import random

from utils import file_io, rir
from utils.logger import info

DEFAULT_GENERATE = {
    "cidr": "0.0.0.0/0",
    "split_to": 16,
    "seed": 0,           # 0 = ngẫu nhiên; >0 = tái lập thứ tự xáo
    "shuffle": True,
    "max_chunks": 0,     # 0 = tất cả
}


def gen_config(cfg):
    """Chuẩn hóa block `scanner.generate_ipv4` (điền default)."""
    gen = dict(DEFAULT_GENERATE)
    gen.update(cfg.get("scanner", {}).get("generate_ipv4") or {})
    return gen


def generate_chunks(cfg):
    """Sinh list CIDR str sau lọc exclude + giới hạn max_chunks."""
    gen = gen_config(cfg)
    try:
        net = ipaddress.ip_network(gen["cidr"], strict=False)
    except ValueError as exc:
        raise ValueError(f"generate_ipv4.cidr không hợp lệ: {gen['cidr']} ({exc})")

    split_to = int(gen["split_to"])
    if split_to < net.prefixlen:
        split_to = net.prefixlen  # không chia nhỏ hơn dải gốc
    try:
        subnets = list(net.subnets(new_prefix=split_to))
    except ValueError:
        subnets = [net]

    exclude_index = rir.ExcludeIndex(cfg["paths"].get("exclude"))
    chunks = [str(s) for s in subnets if not exclude_index.contains(s)]

    if gen.get("shuffle", True):
        rng = random.Random(int(gen.get("seed") or 0) or None)
        rng.shuffle(chunks)

    max_chunks = int(gen.get("max_chunks") or 0)
    if max_chunks > 0:
        chunks = chunks[:max_chunks]

    info(f"[ipgen] {net} → {len(subnets)} chunk /{split_to}; "
         f"sau lọc exclude: {len(chunks)}"
         + (f" (giới hạn {max_chunks})" if max_chunks else ""))
    return chunks


def build_targets(cfg):
    """Ghi targets.txt (CIDR|GEN|IP4) từ generate_chunks; trả (số, generator)."""
    chunks = generate_chunks(cfg)
    targets_path = cfg["paths"]["targets"]
    file_io.write_lines(targets_path, [f"{c}|GEN|IP4" for c in chunks])
    return len(chunks), rir.read_targets(targets_path)
