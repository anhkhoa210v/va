"""Khớp version Magento → CVE offline (không cần nuclei).

Đọc cves/version_map.yaml. Mỗi CVE khai DẢI version dính lỗi theo 2 cách:

  Cách 1 — `ranges` (khuyến nghị, chính xác nhất): danh sách khoảng ĐÓNG
    [lo, hi] bao gồm cả 2 đầu. So theo bộ (major, minor, patch, pnum):
        ranges:
          - ["2.4.0", "2.4.3-p1"]      # 2.4.0..2.4.3-p1 đều dính
          - ["2.3.3-p1", "2.3.7-p2"]   # riêng dòng 2.3.x có lower bound

  Cách 2 — `eol_older_than` (bổ sung cho `ranges`): khai dòng release cũ
    nhất được vendor vá; các nhánh patch nhỏ HƠN (cùng major.minor) là EOL
    — không bao giờ nhận bản vá nên coi như vẫn dính lỗi:
        eol_older_than: "2.4.4"
        # → 2.4.0..2.4.3 (mọi pnum) dính vì hết hỗ trợ, không có bản vá

  Cách 3 — `max_vulnerable` (tương thích bản cũ): mỗi mục "X.Y.Z[-pN]"
    = khoảng [X.Y.Z, X.Y.Z-pN] đóng trên ĐÚNG nhánh (major.minor.patch).
    KHÔNG tự suy diễn sang nhánh cũ hơn (tránh false positive) — muốn gom
    nhánh EOL hãy chuyển sang `ranges` + `eol_older_than`.

Version được so sánh theo bộ 4 số (major, minor, patch, pnum); thiếu patch
= 0, thiếu -pN = 0. Regex có rào cản biên (boundary) + lookahead chặn
suffix mơ hồ như "2.4.6-p3-rc1" / "2.4.6-p3.1" — chỉ khớp token version
sạch, giảm false positive từ chuỗi lạ.
"""
import os
import re

import yaml

from utils.logger import warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_MAP_PATH = os.path.join(BASE_DIR, "cves", "version_map.yaml")

# Regex chặt với boundary:
#   - KHÔNG match khi ký tự trước token là [A-Za-z0-9._-] ("prototype2.4.6",
#     "Magento2.4.6-p3rc") — chỉ cho phép tiền tố đứng sau ký tự không phải
#     chữ/số/dấu (vd "Magento/2.4.6", "v 2.4.6"); chữ "v" đứng ngay sau
#     boundary thì được phép ("v2.4.6" — `(?:v)?` optional sau rào cản).
#   - KHÔNG match khi sau token còn [A-Za-z0-9._-] ("-rc1", ".1", "-p3x").
VERSION_RE = re.compile(
    r"(?<![\w.-])(?:v)?(\d+)\.(\d+)(?:\.(\d+))?(?:-p(\d+))?(?![A-Za-z0-9._-])",
    re.I,
)

CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}$", re.I)
SEVERITIES = ("critical", "high", "medium", "low", "info")


def parse_version(text):
    """text → tuple (major, minor, patch, pnum) hoặc None nếu không phải
    version sạch. Không nhận chuỗi có hậu tố mơ hồ (-rc1, .1, -p3x...)."""
    if not text:
        return None
    match = VERSION_RE.search(str(text))
    if not match:
        return None
    major, minor, patch, pnum = match.groups()
    return (int(major), int(minor), int(patch or 0), int(pnum or 0))


def _valid_cve(cve):
    """CVE-ID hợp lệ → True (tránh key rác trong map gây nhiễu báo cáo)."""
    return bool(CVE_RE.match(str(cve).strip()))


def _fmt_version(v):
    """tuple → 'X.Y[.Z][-pN]' cho báo cáo."""
    major, minor, patch, pnum = v
    base = f"{major}.{minor}"
    if patch:
        base += f".{patch}"
    return f"{base}-p{pnum}" if pnum else base


def _norm_severity(text):
    sev = str(text or "").strip().lower()
    return sev if sev in SEVERITIES else "n/a"


def _bounds_to_tuple(bound, cve, key):
    """'2.4.6-p3' → tuple; None + warn nếu không parse được."""
    parsed = parse_version(bound)
    if parsed is None:
        warn(f"[cve_map] bỏ qua {key} không hợp lệ {bound!r} ({cve})")
        return None
    return parsed


def _legacy_max_to_ranges(raw_list, cve):
    """`max_vulnerable` bản cũ → khoảng đóng theo từng nhánh X.Y.Z.

    Mỗi mục "2.4.6-p5" chỉ phủ nhánh patch=6 (2.4.6-p0..p5) — giữ đúng ngữ
    nghĩa cũ, không suy diễn sang nhánh khác (tránh FP)."""
    ranges = []
    for text in raw_list or []:
        hi = _bounds_to_tuple(text, cve, "max_vulnerable")
        if hi is None:
            continue
        lo = (hi[0], hi[1], hi[2], 0)
        ranges.append((lo, hi, f"{_fmt_version(lo)}..{_fmt_version(hi)}"))
    return ranges


def _load_rule(cve, rule):
    """rule YAML → dict chuẩn {name, severity, ranges: [(lo, hi, label)]}.

    Trả None nếu không có dữ liệu version hợp lệ (CVE vẫn có thể quét qua
    nuclei — xem cve.community_ids)."""
    if not isinstance(rule, dict):
        warn(f"[cve_map] bỏ qua rule không phải dict: {cve}")
        return None

    ranges = []
    raw_ranges = rule.get("ranges") or []
    for pair in raw_ranges:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            warn(f"[cve_map] bỏ qua range không hợp lệ {pair!r} ({cve})")
            continue
        lo = _bounds_to_tuple(str(pair[0]).strip(), cve, "range.lo")
        hi = _bounds_to_tuple(str(pair[1]).strip(), cve, "range.hi")
        if lo is None or hi is None:
            continue
        # ràng buộc cùng family major.minor (chống ghi nhầm lo/hi khác dòng)
        if lo[0:2] != hi[0:2]:
            warn(f"[cve_map] range {pair} lệch family major.minor ({cve}) — bỏ qua")
            continue
        if lo > hi:
            warn(f"[cve_map] range lo > hi {pair} ({cve}) — bỏ qua")
            continue
        ranges.append((lo, hi, f"{_fmt_version(lo)}..{_fmt_version(hi)}"))

    eol_text = rule.get("eol_older_than")
    eol = _bounds_to_tuple(str(eol_text).strip(), cve, "eol_older_than") \
        if eol_text else None

    # tương thích cũ: max_vulnerable → phủ nhánh đóng từng dòng
    for r in _legacy_max_to_ranges(rule.get("max_vulnerable"), cve):
        if r not in ranges:
            ranges.append(r)

    if not ranges and eol is None:
        warn(f"[cve_map] {cve}: không có ranges/eol_older_than hợp lệ — bỏ offline match")
        return None

    return {
        "name": str(rule.get("name") or "").strip(),
        "severity": _norm_severity(rule.get("severity")),
        "cvss": rule.get("cvss"),
        "references": rule.get("references") or [],
        "ranges": ranges,
        "eol_older_than": eol,
    }


def load_map(path=None):
    """path → {CVE-ID: rule chuẩn hóa}. Không bao giờ raise."""
    path = path or DEFAULT_MAP_PATH
    if not os.path.exists(path):
        warn(f"[cve_map] không tìm thấy {path} — bỏ khớp version")
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
    except yaml.YAMLError as exc:
        warn(f"[cve_map] lỗi parse YAML {path}: {exc}")
        return {}
    if not isinstance(raw, dict):
        warn(f"[cve_map] {path} không phải mapping — bỏ khớp version")
        return {}

    result = {}
    for cve, rule in raw.items():
        if not _valid_cve(cve):
            warn(f"[cve_map] bỏ qua key không phải CVE-ID: {cve!r}")
            continue
        loaded = _load_rule(str(cve).upper(), rule)
        if loaded is not None:
            result[str(cve).upper()] = loaded
    return result


def _inside(v, lo, hi):
    """v nằm trong khoảng đóng [lo, hi] (so bộ 4 số)."""
    return lo <= v <= hi


def _eol_hit(v, eol):
    """version thuộc family major.minor của eol và có patch < patch(eol)?

    Đại diện cho các nhánh release CŨ HƠN dòng EOL của vendor (cùng dòng
    major.minor) — không bao giờ nhận bản vá nên vẫn dính lỗi."""
    if eol is None:
        return False
    return v[0:2] == eol[0:2] and v < eol


def match_detail(version_text, version_map=None, map_path=None):
    """version_text → list dict chi tiết CVE khả năng dính lỗi.

    Mỗi dict: {cve, name, severity, cvss, how, label}
    how: 'range' | 'eol' — lý do khớp (để báo cáo & đối chiếu)."""
    if version_map is None:
        version_map = load_map(map_path)
    version = parse_version(version_text)
    if not version:
        return []
    hits = []
    for cve, rule in version_map.items():
        how = None
        label = None
        for lo, hi, label_text in rule["ranges"]:
            if _inside(version, lo, hi):
                how, label = "range", label_text
                break
        if how is None and _eol_hit(version, rule["eol_older_than"]):
            how = "eol"
            label = f"< {_fmt_version(rule['eol_older_than'])} (nhánh EOL)"
        if how:
            hits.append({
                "cve": cve,
                "name": rule["name"],
                "severity": rule["severity"],
                "cvss": rule["cvss"],
                "how": how,
                "label": label,
            })
    return hits


def match(version_text, version_map=None, map_path=None):
    """Back-compat: version_text → list CVE-ID (khả năng dính lỗi)."""
    return [hit["cve"] for hit in match_detail(version_text, version_map, map_path)]




