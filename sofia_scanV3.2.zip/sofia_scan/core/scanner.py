"""STAGE 1: phát hiện host mở cổng (80/443/8080) — engine masscan hoặc zmap.

Hỗ trợ 2 engine quét port:
  - masscan: 1 lần quét nhiều cổng (-p 80,443,8080) → output -oL
  - zmap   : quét từng cổng (per-port loop — tương thích mọi bản zmap,
             kể cả bản chỉ quét 1 cổng/lần) → output mặc định 1 IP/dòng

Chọn engine theo `scanner.engine` trong config:
  - "masscan" / "zmap": dùng đúng engine (warn nếu thiếu binary → fallback auto)
  - "auto" (mặc định): masscan nếu có binary, ngược lại zmap

zmap cần root (raw socket) như masscan; chạy `sudo python3 main.py`.

─── Chống block + chạy dài ngày ổn định ──────────────────────────────────
* CIDR LỚN bị chia CHUNK: mỗi chunk ≤ chunk_max_hosts host (mặc định 262144),
  tối thiểu /16 (chunk_prefix mặc định 16 — cùng mức với chế độ tự sinh IPv4).
  Chunk nhỏ = 1 lần chạy engine ngắn → ít gây chú ý, dễ gom kết quả.
* RESUME TỪNG CHUNK: chunk nào xong được ghi ngay vào
  output/work/<slug>/scan_chunks_done.txt + kết quả gộp vào live_chunks.txt.
  Crash/block giữa CIDR → lần sau chỉ quét lại các chunk còn dang dở.
* RETRY + BACKOFF: engine exit != 0 (mạng rớt, bị chặn tạm) → thử lại
  `scanner.retries` lần, ngủ tăng dần (retry_backoff_base * 2^n + jitter).
* POLITENESS: ngủ ngẫu nhiên chunk_sleep_min..max giây GIỮA các chunk của cùng
  CIDR (nhịp đều, không quét liên tục 1 vùng khiến dễ bị nhà mạng để ý).
* max_scan_seconds > 0 → truyền --max-time cho masscan và chặn mềm mỗi lần
  chạy engine qua timeout (tránh 1 lần quét "bất tử" kẹt cả pipeline).
* masscan nhận thêm --seed / --source-port / --source-ip / -e nếu khai trong
  config (tái lập + điều khiển nguồn phát — hữu ích khi cần cố định seed để
  so sánh, hoặc đổi source IP khi bị chặn).
"""
import ipaddress
import os
import random
import shutil
import time

from utils import file_io, runner
from utils.logger import info, warn

DEFAULT_PORTS = "80,443,8080"
DEFAULT_CHUNK_MAX_HOSTS = 262144   # 2^18 — 1 chunk quét tối đa ngần này host
DEFAULT_CHUNK_PREFIX = 16          # chunk nhỏ nhất /16 (65536 host) — floor
DEFAULT_MAX_SCAN_SECONDS = 3600    # chặn mềm 1 lần chạy engine khi không khai
DEFAULT_RETRIES = 2
DEFAULT_RETRY_BACKOFF_BASE = 15    # giây

CHUNK_DONE_FILE = "scan_chunks_done.txt"
CHUNK_LIVE_FILE = "live_chunks.txt"

# Các thư mục binary chuẩn — /usr/sbin (zmap) có thể thiếu trong PATH user
_COMMON_PATHS = ("/usr/bin", "/usr/sbin", "/usr/local/bin",
                 "/usr/local/sbin", "/bin", "/sbin")


def _find(binary):
    """shutil.which + fallback quét thư mục chuẩn (zmap thường ở /usr/sbin)."""
    path = shutil.which(binary)
    if path:
        return path
    for base in _COMMON_PATHS:
        candidate = os.path.join(base, binary)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _is_ipv4(text):
    try:
        return ipaddress.IPv4Address(text.strip()).version == 4
    except ValueError:
        return False


def parse_list_file(path):
    """Parse masscan -oL (list format): 'open tcp <port> <ip> <ts>' → ip:port."""
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open" and parts[1] == "tcp":
                out.append(f"{parts[3]}:{parts[2]}")
    return file_io.dedupe_sort(out)


def parse_zmap_output(path, port):
    """Parse zmap output → list 'ip:port'.

    Hỗ trợ 2 định dạng:
      - mặc định: 1 IP mỗi dòng (output-fields = saddr)
      - CSV: 'ip,port' nếu output-fields gồm saddr,sport
    Bỏ qua comment (dòng bắt đầu bằng #) và dòng trống.
    """
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "," in line:
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2 and _is_ipv4(parts[0]) and parts[1].isdigit():
                    out.append(f"{parts[0]}:{parts[1]}")
            elif _is_ipv4(line):
                out.append(f"{line}:{port}")
    return file_io.dedupe_sort(out)


def _engine_config(cfg):
    """Trả về dict chuẩn hóa của block `scanner` (engine/ports/masscan/zmap/chunk)."""
    sc = cfg.get("scanner") or {}
    return {
        "engine": (sc.get("engine") or "auto").lower(),
        "ports": str(sc.get("ports") or DEFAULT_PORTS),
        "masscan": sc.get("masscan") or {},
        "zmap": sc.get("zmap") or {},
        "chunk_max_hosts": int(sc.get("chunk_max_hosts") or DEFAULT_CHUNK_MAX_HOSTS),
        "chunk_prefix": int(sc.get("chunk_prefix") or 0),  # 0 = tự suy từ chunk_max_hosts
        "chunk_sleep_min": float(sc.get("chunk_sleep_min") or 0.0),
        "chunk_sleep_max": float(sc.get("chunk_sleep_max") or 0.0),
        "retries": int(sc.get("retries") or DEFAULT_RETRIES),
        "retry_backoff_base": int(sc.get("retry_backoff_base")
                                   or DEFAULT_RETRY_BACKOFF_BASE),
        "max_scan_seconds": int(sc.get("max_scan_seconds") or 0),
    }


def pick_engine(cfg):
    """Chọn engine khả dụng theo config; trả về 'masscan' | 'zmap' | None."""
    sc = _engine_config(cfg)
    engine = sc["engine"]
    if engine in ("masscan", "zmap"):
        if _find(engine):
            return engine
        warn(f"[scanner] engine '{engine}' không có binary — thử 'auto'")
    if _find("masscan"):
        return "masscan"
    if _find("zmap"):
        return "zmap"
    return None


# ─── Chunk CIDR lớn ─────────────────────────────────────────────────────


def _chunk_prefix(sc):
    """Prefix mỗi chunk.

    - chunk_prefix khai rõ (>0) → dùng thẳng (chỉ siết lại nếu vượt
      chunk_max_hosts).
    - mặc định tự suy: prefix tối đa mà 2^(32-p) <= chunk_max_hosts, nhưng
      không quá thô hơn /16 (floor — 1 lần quét ≤ 65536 host, cùng mức chế độ
      tự sinh IPv4) → mặc định cho ra /16.
    """
    max_hosts = max(1, sc["chunk_max_hosts"])
    preferred = sc["chunk_prefix"]
    if preferred > 0:
        prefix = preferred
    else:
        # cần prefix p sao cho 2^(32-p) <= max_hosts → p >= 32 - ceil(log2(max_hosts))
        needed = 32 - (max_hosts - 1).bit_length()
        prefix = max(DEFAULT_CHUNK_PREFIX, needed)
    while prefix < 30 and (1 << (32 - prefix)) > max_hosts:
        prefix += 1
    return prefix


def _iter_chunks(network, prefix):
    """Chunk đều theo prefix: CIDR nhỏ hơn → chạy nguyên 1 lần (yield chính nó)."""
    if network.prefixlen >= prefix:
        yield network
        return
    yield from network.subnets(new_prefix=prefix)


def _chunk_dir(workdir):
    chunk_dir = os.path.join(workdir, "chunks")
    os.makedirs(chunk_dir, exist_ok=True)
    return chunk_dir


def _read_done(workdir):
    """Set chunk CIDR đã quét xong (resume từng chunk)."""
    path = os.path.join(workdir, CHUNK_DONE_FILE)
    return set(file_io.read_lines(path))


def _mark_done(workdir, chunk):
    file_io.append_line(os.path.join(workdir, CHUNK_DONE_FILE), str(chunk))


def _accumulate(workdir, hosts):
    file_io.append_lines(os.path.join(workdir, CHUNK_LIVE_FILE), hosts)


def _scan_chunks(cidr, workdir, sc, cfg, chunk_runner):
    """Chia CIDR → chunk, chạy từng chunk có retry/backoff + resume.

    chunk_runner(network_text, chunk_dir) → list 'ip:port' nếu OK, None nếu lỗi.
    Trả list 'ip:port' gộp TẤT CẢ chunk đã xong (cũ + mới). Raise RuntimeError
    nếu 1 chunk thất bại hết lượt retry (để pipeline không đánh dấu .complete —
    lần chạy sau resume phần còn dang dở).
    """
    prefix = _chunk_prefix(sc)
    network = ipaddress.ip_network(cidr, strict=False)
    chunks = list(_iter_chunks(network, prefix))
    if len(chunks) > 1:
        info(f"[{cidr}] chia {len(chunks)} chunk /{prefix} — "
             f"{1 << (32 - prefix)} host/chunk (resume từng chunk)")

    done = _read_done(workdir)
    remaining = [chunk for chunk in chunks if str(chunk) not in done]
    if done and len(remaining) < len(chunks):
        info(f"[{cidr}] resume: {len(chunks) - len(remaining)}/{len(chunks)} "
             f"chunk đã xong trước đó — quét tiếp {len(remaining)} chunk")

    chunk_dir = _chunk_dir(workdir)
    sleep_span = sc["chunk_sleep_max"] - sc["chunk_sleep_min"]
    for idx, chunk in enumerate(remaining):
        chunk_text = str(chunk)
        attempts = max(1, sc["retries"] + 1)
        hosts = None
        last_err = ""
        for attempt in range(1, attempts + 1):
            hosts = chunk_runner(chunk_text, chunk_dir)
            if hosts is not None:
                break
            last_err = f"chunk {chunk_text} thất bại lần {attempt}/{attempts}"
            if attempt < attempts:
                backoff = sc["retry_backoff_base"] * (2 ** (attempt - 1))
                backoff += random.uniform(0, sc["retry_backoff_base"] / 2)
                warn(f"[scanner] {last_err} — thử lại sau {backoff:.0f}s")
                time.sleep(backoff)
        if hosts is None:
            raise RuntimeError(f"{last_err} — đã cạn lượt retry (xem log engine)")
        _accumulate(workdir, hosts)
        _mark_done(workdir, chunk)
        # politeness giữa các chunk của cùng CIDR
        if idx < len(remaining) - 1 and sleep_span > 0:
            time.sleep(sc["chunk_sleep_min"] + random.random() * sleep_span)

    merged = file_io.dedupe_sort(file_io.read_lines(
        os.path.join(workdir, CHUNK_LIVE_FILE)))
    return merged


def _runner_timeout(sc):
    """Chặn mềm 1 lần chạy engine (giây)."""
    return sc["max_scan_seconds"] or DEFAULT_MAX_SCAN_SECONDS


def _masscan_chunk_runner(sc, cfg):
    def run_chunk(chunk_text, chunk_dir):
        slug = file_io.slugify(chunk_text)
        targets_file = os.path.join(chunk_dir, f"{slug}.txt")
        raw = os.path.join(chunk_dir, f"{slug}.list")
        file_io.atomic_write(targets_file, chunk_text + "\n")

        mc = sc["masscan"]
        rate = mc.get("rate") or cfg.get("rate", 10000)
        wait = mc.get("wait", 0)
        cmd = [
            "masscan", "-iL", targets_file, "-p", sc["ports"],
            "--rate", str(rate), "--wait", str(wait),
            "-oL", raw,
        ]
        # các tùy chọn giúp tái lập / điều khiển nguồn phát (chống block)
        if mc.get("seed"):
            cmd += ["--seed", str(mc["seed"])]
        if mc.get("source_port"):
            cmd += ["--source-port", str(mc["source_port"])]
        if mc.get("source_ip"):
            cmd += ["--source-ip", str(mc["source_ip"])]
        if mc.get("interface"):
            cmd += ["-e", str(mc["interface"])]
        if sc["max_scan_seconds"] > 0:
            cmd += ["--max-time", str(sc["max_scan_seconds"])]

        proc = runner.run(cmd, timeout=_runner_timeout(sc))
        if proc.returncode == 124:
            warn(f"[masscan] chunk {chunk_text} quá {_runner_timeout(sc)}s — bị chặn")
            return None
        if proc.returncode != 0 and proc.stderr:
            warn(f"[masscan] chunk {chunk_text} exit {proc.returncode}: "
                 f"{proc.stderr.strip()[-300:]}")
            return None
        if proc.returncode != 0:
            warn(f"[masscan] chunk {chunk_text} exit {proc.returncode} (không có stderr)")
            return None
        return parse_list_file(raw)
    return run_chunk


# Cache tên flag exclude của zmap (khác nhau giữa các bản)
_ZMAP_EXCLUDE_FLAG = {"flag": None}


def _zmap_exclude_flag():
    """zmap >= 4 dùng --exclude-file; bản cũ dùng --blacklist-file."""
    cached = _ZMAP_EXCLUDE_FLAG["flag"]
    if cached:
        return cached
    flag = "--exclude-file"
    try:
        help_text = runner.run(["zmap", "--help"], timeout=30).stdout or ""
        if flag not in help_text and "--blacklist-file" in help_text:
            flag = "--blacklist-file"
    except Exception:
        pass
    _ZMAP_EXCLUDE_FLAG["flag"] = flag
    return flag


def _zmap_chunk_runner(sc, cfg):
    zm = sc["zmap"]
    ports = [p.strip() for p in sc["ports"].split(",") if p.strip()]

    def run_chunk(chunk_text, chunk_dir):
        slug = file_io.slugify(chunk_text)
        targets_file = os.path.join(chunk_dir, f"{slug}.txt")
        file_io.atomic_write(targets_file, chunk_text + "\n")

        rate = zm.get("rate") or cfg.get("rate", 10000)
        chunk_hosts = []
        for port in ports:
            raw = os.path.join(chunk_dir, f"{slug}_p{port}.out")
            # zmap giới hạn dải quét bằng -w/--whitelist-file (không có -iL)
            cmd = ["zmap", "-p", port, "-w", targets_file,
                   "--rate", str(rate), "-o", raw]
            if zm.get("bandwidth"):
                cmd += ["--bandwidth", str(zm["bandwidth"])]
            if zm.get("cooldown") is not None:
                cmd += ["--cooldown", str(zm["cooldown"])]
            if zm.get("seed"):
                cmd += ["--seed", str(zm["seed"])]
            if zm.get("source_port"):
                cmd += ["--source-port", str(zm["source_port"])]
            if zm.get("interface"):
                cmd += ["-i", str(zm["interface"])]
            if zm.get("quiet", True):
                cmd += ["--quiet"]
            if zm.get("dryrun"):
                cmd += ["--dryrun"]  # chỉ validate config, không gửi gói
            excl = zm.get("exclude_file") or ""
            if excl and os.path.exists(excl):
                cmd += [_zmap_exclude_flag(), excl]
            extra = zm.get("extra_args") or []
            if extra:
                cmd += [str(a) for a in extra]

            proc = runner.run(cmd, timeout=_runner_timeout(sc))
            if proc.returncode == 124:
                warn(f"[zmap] chunk {chunk_text} port {port} quá "
                     f"{_runner_timeout(sc)}s — bị chặn")
                return None
            if proc.returncode != 0 and proc.stderr:
                warn(f"[zmap] chunk {chunk_text} port {port} exit {proc.returncode}: "
                     f"{proc.stderr.strip()[-300:]}")
                return None
            if proc.returncode != 0:
                warn(f"[zmap] chunk {chunk_text} port {port} exit "
                     f"{proc.returncode} (không có stderr)")
                return None
            chunk_hosts += parse_zmap_output(raw, port)
        return file_io.dedupe_sort(chunk_hosts)
    return run_chunk


def scan_masscan(cidr, workdir, global_live, cfg):
    """Quét CIDR bằng masscan (tự chia chunk nếu lớn); trả list 'ip:port'."""
    sc = _engine_config(cfg)
    return _scan_chunks(cidr, workdir, sc, cfg, _masscan_chunk_runner(sc, cfg))


def scan_zmap(cidr, workdir, global_live, cfg):
    """Quét CIDR bằng zmap (tự chia chunk nếu lớn); trả list 'ip:port'."""
    sc = _engine_config(cfg)
    return _scan_chunks(cidr, workdir, sc, cfg, _zmap_chunk_runner(sc, cfg))


def scan(cidr, workdir, global_live, cfg):
    """Quét 1 CIDR bằng engine đã chọn; append vào global_live; trả 'ip:port'.

    Chunk đã xong (scan_chunks_done.txt) được bỏ qua khi chạy lại CIDR này —
    resume ở mức chunk, an toàn cho lần quét dài ngày bị ngắt giữa chừng.
    """
    engine = pick_engine(cfg)
    hosts = []
    if engine == "masscan":
        hosts = scan_masscan(cidr, workdir, global_live, cfg)
    elif engine == "zmap":
        hosts = scan_zmap(cidr, workdir, global_live, cfg)
    else:
        warn("[scanner] không tìm thấy masscan/zmap — bỏ qua stage 1")

    file_io.append_lines(global_live, hosts)
    info(f"[{cidr}] stage1 ({engine or 'none'}): {len(hosts)} host mở "
         f"{_engine_config(cfg)['ports']}")
    return hosts

