# Sofia Scan

QuétMagento hàng loạt theo dải IP tự sinh từ **5 RIR** (APNIC, RIPE, ARIN, LACNIC, AFRINIC),
chạy nhiều stage theo từng CIDR, **lọc ra cửa hàng thật** rồi quét CVE và thông báo
qua **webhook** (Discord/Slack).

```
main.py ─▶ utils/rir.py ─▶ targets.txt (CIDR|rir|quốc_gia)
        └▶ config/targets_extra.txt  hotspot CIDR ưu tiên quét TRƯỚC RIR
        └▶ core/pipeline.py — với MỖI CIDR:
             webhook "🔎 Đang Quét <CIDR> (<quốc gia>)"
             STAGE 1  scanner.py      masscan|-iL|-p80,443,8080|-oL  → output/live.txt
             (engine stage 1: masscan | zmap | auto — xem `scanner.engine`)
             CIDR lớn chia chunk /16, resume từng chunk, retry/backoff,
             politeness giữa các CIDR (pipeline) — xem `scanner.*` bên dưới
             STAGE 2a fingerprint.py  probe đa endpoint + điểm tin cậy → output/magento.txt
                 /rest/V1/ /graphql /static/version/ /magento_version (+httpx tech-detect)
                 ngưỡng fingerprint.min_score (mặc định 3), debug ra work/<slug>/magento_scored.txt
             STAGE 2c store_detect.py  probe storefront → chỉ giữ "cửa hàng THẬT"
                 trang chủ marker bán hàng / /checkout/cart/ /customer/account/login/
                 retry lỗi mạng + jitter + threads riêng + đếm lý do loại
                 → output/stores.txt (global) + work/<slug>/stores_scored.txt
                   + work/<slug>/stores_reasons.txt (bảng đếm — điều chỉnh ngưỡng)
                 ngưỡng store_detect.min_score (mặc định 3)
             STAGE 2b versioning.py   /magento_version → /static/version/ JSON → magento_versions.txt
                 — chỉ chạy trên các URL là CỬA HÀNG THẬT (output của 2c)
             STAGE 3  cve_scan.py     offline version→CVE (cves/version_map.yaml,
                                      ranges + eol_older_than) — luôn chạy
                                      + nuclei (bật tắt qua cve.nuclei.enabled):
                                      template local (-t, id khớp tên file) +
                                      community (-id, trừ CVE đã chạy local) → output/vuln.txt
             STAGE 4  resolver.py     dig PTR + openssl SAN/CN → output/t.txt
                 (t.txt = domain cửa hàng THẬT — loại maintenance/coming-soon/blog)
             finally: webhook "✅ Đã Ghi Vào File t.txt <N> domain — dải ... hoàn tất"

        Ngoài ra: upload_live.py — daemon upload output/t.txt lên GoFile định kỳ
        và gửi link về webhook (mở trong main.py, xem cấu hình `upload`).
```

## Cài đặt

```bash
pip install -r requirements.txt
pip install pytest          # chỉ để chạy tests

# binary ngoài (nếu thiếu):
#   masscan, zmap, httpx (projectdiscovery), nuclei (projectdiscovery), dig (bind9-dnsutils), openssl
sudo apt install masscan zmap bind9-dnsutils openssl
```

## Sử dụng

```bash
# Sinh targets.txt từ tất cả RIR, lọc exclude, rồi quét toàn bộ
sudo python3 main.py

# Chỉ sinh targets.txt (lọc Việt Nam + Thái Lan) rồi thoát
python3 main.py --countries VN,TH --targets-only

# Ghi đè rate/thread, tắt resume
sudo python3 main.py --rate 20000 --threads 100 --no-resume

# Bắt buộc dùng zmap cho stage 1 (mặc định auto: masscan nếu có, ngược lại zmap)
sudo python3 main.py --countries SG --engine zmap

# Tự sinh IPv4 — quét toàn bộ internet bằng zmap (80/443/8080), không cần RIR
sudo python3 main.py --generate-ipv4 --engine zmap
# Thử nhanh: chỉ 2 chunk /24 trong 1.0.0.0/8, không quét thật
python3 main.py --generate-ipv4 --gen-cidr 1.0.0.0/8 --split-to 24 --max-chunks 2 --targets-only
```

> `masscan` cần quyền root (`sudo`). Stage fingerprint/versioning chạy bằng Python threads.

## Cấu hình — `config/config.yaml`

| Khóa | Ý nghĩa |
|---|---|
| `scanner.engine` | engine stage 1: `masscan` / `zmap` / `auto` (auto = masscan nếu có, ngược lại zmap) |
| `scanner.ports` | danh sách cổng quét, ví dụ `80,443,8080` |
| `scanner.masscan.rate` / `.wait` | tốc độ masscan (gói/giây) / giây chờ sau khi quét |
| `scanner.masscan.seed` | seed cố định `--seed` cho masscan (0 = ngẫu nhiên — tái lập để so sánh) |
| `scanner.masscan.source_port` / `.source_ip` / `.interface` | source port / IP nguồn / giao diện `-e` (đổi nguồn khi bị chặn) |
| `scanner.chunk_max_hosts` | host tối đa mỗi chunk khi CIDR lớn (mặc định 262144 = /16) — quyết định prefix mặc định |
| `scanner.chunk_prefix` | prefix mỗi chunk (0 = tự suy từ `chunk_max_hosts`, floor /16; >0 = cố định) |
| `scanner.retries` / `.retry_backoff_base` | thử lại engine khi 1 chunk lỗi, ngủ `base*2^(n-1)` + jitter giữa các lần thử |
| `scanner.max_scan_seconds` | 0 = chặn mềm 3600s/lần engine; >0 = truyền `--max-time` cho masscan + timeout runner |
| `scanner.chunk_sleep_min` / `.chunk_sleep_max` | politeness giữa các CHUNK cùng CIDR (0/0 = tắt) |
| `scanner.politeness.sleep_min` / `.sleep_max` | pipeline ngủ ngẫu nhiên GIỮA các CIDR (0/0 = tắt) — chống block nguồn quét |
| `scanner.zmap.rate` / `.bandwidth` | tốc độ zmap (gói/giây) / bandwidth ví dụ `100M` (ghi đè rate) |
| `scanner.zmap.cooldown` | giây chờ gói trả về sau khi zmap scan xong |
| `scanner.zmap.seed` | seed ngẫu nhiên hóa thứ tự quét (0 = ngẫu nhiên) |
| `scanner.zmap.source_port` | source port (ví dụ `40000` hoặc `40000-41000`) |
| `scanner.zmap.exclude_file` | file CIDR loại trừ tùy chọn cho zmap |
| `scanner.zmap.quiet` | tắt status updates của zmap |
| `scanner.zmap.dryrun` | `true` = chỉ validate config, không gửi gói (test) — zmap 2.x có bug assertion khi dryrun với CIDR >1 IP, chỉ dùng cho 1 IP |
| `scanner.generate_ipv4.enabled` | `true` = tự sinh chunk IPv4 từ `cidr`, bỏ qua RIR (không cần targets.txt) |
| `scanner.generate_ipv4.cidr` | dải gốc, mặc định `0.0.0.0/0` (toàn bộ IPv4) |
| `scanner.generate_ipv4.split_to` | chia thành chunk /N, mặc định 16 → 65.536 chunk |
| `scanner.generate_ipv4.shuffle` / `.seed` | xáo thứ tự chunk / seed tái lập thứ tự |
| `scanner.generate_ipv4.max_chunks` | `0` = tất cả; `>0` = giới hạn số chunk (test) |
| `scanner.ports` | cổng quét (mặc định `80,443,8080`) — dùng chung cho tự sinh |
| `rate` | tốc độ quét (gói/giây) — fallback khi `scanner.*.rate` trống |
| `threads` | số thread fingerprint/versioning |
| `timeout` | timeout HTTP |
| `cves` | danh sách CVE có template local trong `cves/` (đưa vào nuclei `-t`) |
| `fingerprint.endpoints` | endpoint probe thêm ngoài trang chủ (mặc định `/rest/V1/`, `/graphql`, `/static/version/`, `/magento_version`) |
| `fingerprint.min_score` | ngưỡng điểm tin cậy để kết luận Magento (mặc định 3) |
| `store_detect.enabled` | `true` = bật stage 2c lọc cửa hàng thật; `false` = chạy như bản cũ (mọi URL Magento đi tiếp) |
| `store_detect.min_score` | ngưỡng điểm cửa hàng thật (mặc định 3) |
| `store_detect.check_cart` / `.check_login` | probe `/checkout/cart/` (giỏ hàng) và `/customer/account/login/` (đăng nhập khách) — bật mặc định |
| `store_detect.threads` | số worker RIÊNG của stage (mặc định 20 — không tranh fingerprint) |
| `store_detect.retries` | thử lại LỖI MẠNG tạm thời (mặc định 1; không retry 429/503) |
| `store_detect.jitter_min` / `.jitter_max` | ngủ ngẫu nhiên (giây) TRƯỚC mỗi URL — giãn nhịp chống WAF chặn |
| `store_detect.head_limit` | byte đầu body + `<title>` để tìm dấu hiệu "chưa mở bán" (mặc định 6144) |
| `cve.version_map` | `cves/version_map.yaml` — khớp version (stage 2b) → CVE offline, không cần nuclei |
| `cve.nuclei.enabled` | `false` = chỉ khớp version offline, không gọi nuclei |
| `cve.nuclei.concurrency` / `.rate_limit` / `.timeout` / `.retries` | cờ nuclei `-c` / `-rl` / `-timeout` / `-retries` (0/trống = để nuclei tự chọn hoặc mặc định) |
| `cve.nuclei.follow_redirects` | `true` = nuclei theo redirect (mặc định tắt — tránh quét lạc; lưu ý đây là follow-redirects, KHÔNG phải "giảm false positive") |
| `cve.nuclei.max_seconds` | chặn mềm 1 lượt nuclei — quá giờ giữ kết quả một phần (mặc định 7200) |
| `cve.nuclei.local_templates` / `.community` | bật/tắt từng nguồn template (local trong `cves/` / cộng đồng qua `-id`) |
| `cve.nuclei.severity` | chỉ giữ finding mức này trở lên, vd `high` (rỗng = tất cả) |
| `cve.community_ids` | CVE chạy qua nuclei `-id` từ nuclei-templates cộng đồng (cần đã cài templates) |
| `paths.targets_extra` | `config/targets_extra.txt` — hotspot CIDR ưu tiên quét trước RIR (mỗi dòng `CIDR` hoặc `CIDR|EXTRA|COUNTRY`) |
| `rir.countries` | rỗng = mọi quốc gia; ví dụ `[VN, TH]` |
| `rir.min_prefix` / `max_prefix` | giới hạn prefix CIDR được chấp nhận |
| `rir.split_to` | chia allocation lớn xuống /N (mặc định 24) |
| `upload.enabled` | bật daemon upload `output/t.txt` lên GoFile định kỳ (mặc định true) |
| `upload.interval` | chu kỳ upload, giây (mặc định 900 = 15 phút) |
| `upload.only_changed` | `true` = bỏ lượt nếu nội dung t.txt không đổi |
| `webhook.enabled/type/url` | bật webhook `discord` / `slack` / `generic` |

Dải loại trừ (gov/mil/CDN...) khai báo trong `config/exclude.txt` (một CIDR mỗi dòng).

## Resume

Mỗi CIDR hoàn tất tạo marker `output/work/<slug>/.complete` — chạy lại `main.py` sẽ
**bỏ qua** các CIDR đó; dùng `--no-resume` để quét lại từ đầu.

Resume còn ở mức **chunk** (stage 1): CIDR lớn chia chunk, chunk nào xong ghi ngay
`output/work/<slug>/scan_chunks_done.txt` + gộp kết quả vào `live_chunks.txt`.
Crash/block giữa CIDR → lần chạy sau chỉ quét lại các chunk còn dang dở.

## Phát hiện CVE — 2 lớp

1. **Offline (version match)** — không cần nuclei, không gửi thêm request:
   version lấy từ stage 2b khớp `cves/version_map.yaml` → ghi `[version] <url> <ver> — khả năng <CVE>`
   vào `output/vuln.txt` và `output/work/<slug>/cve_version.txt`.
2. **Online (nuclei)** — trên các cửa hàng thật (URL từ stage 2c), bật/tắt qua
   `cve.nuclei.enabled`:
   - template local: `cves/<CVE>.yaml` qua `-t` — `id` trong template PHẢI khớp
     tên file (lệch là bỏ qua, chống gán nhầm CVE cho kết quả);
   - template cộng đồng: `cve.community_ids` qua `-id` (cần `nuclei-templates` đã
     cài: `nuclei -update-templates`). CVE vừa có template local vừa trong
     `community_ids` → chỉ chạy bản local (tránh quét trùng 1 CVE 2 lần).
   - Mức độ ăn to điều khiển qua `cve.nuclei.*` (concurrency/rate_limit/timeout/
     retries/follow_redirects/max_seconds/severity — xem bảng cấu hình).
     Lưu ý: `follow_redirects` (cờ `-fr` của nuclei) là theo redirect, KHÔNG phải
     "giảm false positive" như chú thích bản cũ.

CVE có template local hiện tại: `cves/CVE-2022-24086.yaml`, `cves/CVE-2024-34102.yaml`,
`cves/CVE-2025-54236.yaml` (nhận diện Magento, version thủ công). Nếu nuclei không tìm thấy
template community cho CVE nào thì chỉ cần chạy `nuclei -update-templates`.

### Khớp version offline — `cves/version_map.yaml`

Mỗi CVE khai **`ranges`**: danh sách khoảng ĐÓNG `[lo, hi]` (lo/hi phải cùng family
major.minor, parser tự loại nếu lệch). Version dính lỗi khi NẰM TRONG ≥1 khoảng:

```yaml
CVE-2022-24086:
  ranges:
    - ["2.4.0", "2.4.3-p1"]     # 2.4.0..2.4.3-p1 đều dính
    - ["2.3.3-p1", "2.3.7-p2"]
```

**`eol_older_than`** khai dòng release cũ nhất còn được vendor vá — mọi version cùng
family major.minor NHỎ HƠN dòng đó thuộc nhánh EOL, không bao giờ nhận bản vá nên coi
như vẫn dính lỗi (chỉ khai khi chắc chắn nhánh đó không được backport):

```yaml
CVE-2024-34102:
  eol_older_than: "2.4.4"      # → 2.4.0..2.4.3 (mọi pnum) vẫn dính
  ranges:
    - ["2.4.4", "2.4.4-p8"]
    - ["2.4.5", "2.4.5-p7"]
```

Parser version chặt: chỉ nhận token `X.Y[.Z][-pN]` sạch (có boundary, chặn hậu tố mơ hồ
như `-rc1`/`.1`/`-p3x`) — giảm false positive từ chuỗi lạ. Key cũ `max_vulnerable` vẫn
được đọc (mỗi mục = khoảng đóng trên ĐÚNG nhánh X.Y.Z, không suy diễn sang nhánh EOL).

## Lọc "cửa hàng THẬT" (stage 2c)

`fingerprint` chỉ xác nhận **có Magento** — nhưng nhiều URL thoả fingerprint không phải cửa
hàng đang bán: maintenance mode, "coming soon", cài mới chưa setup, Magento làm
blog/CMS/landing, hay trang chết chỉ còn REST mở.

Stage 2c (`core/store_detect.py`) probe thêm đặc tính storefront và chấm điểm:

| Bằng chứng | Điểm |
|---|---|
| Trang chủ 200 + marker bán hàng (catalog/giỏ/tìm kiếm/tài khoản) | +3 |
| `/checkout/cart/` trả 200 — giỏ hàng hoạt động | +3 |
| `/checkout/cart/` redirect | +1 |
| `/customer/account/login/` trả 200 — có tài khoản khách | +2 |
| Trang chủ không phải 2xx (403/404/5xx) | −8 (vẫn probe tiếp) |
| 503 "Service Temporarily Unavailable" / body "coming soon / under construction..." | loại ngay |

Tổng `>= store_detect.min_score` (mặc định 3) → cửa hàng THẬT. Chỉ các URL này được đưa
xuống stage 2b-4; toàn bộ URL Magento vẫn nằm trong `output/magento.txt`.

Output:

| File | Nội dung |
|---|---|
| `output/stores.txt` | 1 URL cửa hàng thật mỗi dòng (global, mọi CIDR) |
| `output/work/<slug>/stores_scored.txt` | `url <điểm> <bằng chứng>` (debug từng CIDR) |
| `output/work/<slug>/stores_reasons.txt` | `số_lần <lý do loại>` — bảng đếm để điều chỉnh ngưỡng (vd quá nhiều `home:503-maintenance` = nhiều site bảo trì) |

Dấu hiệu "chưa mở bán" chỉ tìm trong `store_detect.head_limit` byte đầu + `<title>`
(không quét cả body — tránh false positive từ quảng cáo/blog nhắc "coming soon").
429/503/connect-lỗi không retry (retry chỉ áp dụng cho lỗi mạng tạm thời).

## Upload t.txt lên GoFile định kỳ (`upload_live.py`)

`t.txt` = danh sách **domain cửa hàng thật** — kết quả cuối của pipeline. `upload_live.py`
upload file này lên GoFile rồi gửi link về webhook:

- **Tích hợp `main.py`**: khởi động daemon background qua `upload_live.start_daemon(cfg)`
  (khi `upload.enabled=true`), mỗi `upload.interval` giây upload 1 lần. Trước khi upload tự
  loại dòng trùng trong t.txt (pipeline append theo CIDR — chạy lại sẽ trùng).
- **Chạy riêng**: `python3 upload_live.py [--once] [--file output/t.txt] [--interval 900]`
  (`--only-changed` chỉ upload khi nội dung đổi).

Tin nhắn webhook kèm số domain, dung lượng và link tải. Nếu GoFile/webhook lỗi sẽ báo 1 lần
khi chuyển trạng thái OK → lỗi (chống spam) và thử lại chu kỳ sau.


## Nâng tỉ lệ tìm Magento

- **Hotspot**: điền dải hosting/cloud hay dựng Magento vào `config/targets_extra.txt`
  (`CIDR|EXTRA|COUNTRY`), chúng được quét trước toàn bộ RIR.
- **Tăng nhận diện**: probe đa endpoint nên bắt được cả site đổi theme nhưng còn REST/GraphQL;
  muốn an toàn hơn tăng `fingerprint.min_score`, muốn nhạy hơn giảm còn 2 (kèm false positive).
- **Tăng trúng CVE**: `cve.version_map` tận dụng cả version không cần nuclei; thêm CVE mới vào
  `cve.community_ids` + kéo template bằng `nuclei -update-templates`.

## Tests

```bash
cd sofia_scan && python3 -m pytest tests/ -v
```

Phủ: parse/delegated → CIDR (`test_rir.py`), format tin nhắn webhook (`test_webhook.py`),
signature Magento 1/2 (`test_fingerprint.py`), mock dig + SAN (`test_resolver.py`),
thứ tự stage + webhook trong `finally` + resume (`test_pipeline.py`).










