#!/usr/bin/env python3
"""Sofia Scan — entry point.

Điều phối: RIR (sinh targets.txt) → 4 stage (masscan → fingerprint →
versioning → nuclei → resolver) → webhook thông báo mỗi CIDR.
"""
import argparse
import copy
import ipaddress
import itertools
import os
import sys

import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from utils import file_io, ipgen, rir
from utils.logger import error, info, setup_file_logging, success, warn
from core.pipeline import Pipeline
import upload_live

DEFAULT_CONFIG = {
    "rate": 10000,
    "threads": 50,
    "timeout": 15,
    # Stage 1 — engine quét port: masscan | zmap | auto
    "scanner": {
        "engine": "auto",
        "ports": "80,443,8080",
        "masscan": {"rate": 10000, "wait": 0},
        "zmap": {
            "rate": 10000, "bandwidth": "", "cooldown": 5,
            "seed": 0, "source_port": "", "interface": "",
            "exclude_file": "", "quiet": True, "dryrun": False,
            "extra_args": [],
        },
        # Tự sinh IPv4 thay vì RIR (xem utils/ipgen.py)
        "generate_ipv4": {
            "enabled": False,
            "cidr": "0.0.0.0/0",
            "split_to": 16,
            "shuffle": True,
            "seed": 0,
            "max_chunks": 0,
        },
    },
    "cves": ["CVE-2022-24086", "CVE-2024-34102", "CVE-2025-54236"],
    # Stage 2a — nhận diện Magento: probe đa endpoint + điểm tin cậy
    "fingerprint": {
        "endpoints": ["/rest/V1/", "/graphql", "/static/version/", "/magento_version"],
        "min_score": 3,
    },
    # Stage 3 — CVE: khớp version offline + nuclei cộng đồng
    "cve": {
        "version_map": "cves/version_map.yaml",
        "community_ids": [
            "CVE-2022-24086", "CVE-2022-24087", "CVE-2024-34102",
            "CVE-2024-45115", "CVE-2025-51362", "CVE-2025-54236",
        ],
    },
    # Giới hạn sofia.log (xoay vòng): mỗi file tối đa 10MB, giữ 2 backup
    "log": {
        "max_bytes": 10 * 1024 * 1024,
        "backups": 2,
    },
    "paths": {
        "targets": "targets.txt",
        "exclude": "config/exclude.txt",
        "targets_extra": "config/targets_extra.txt",
        "output_dir": "output",
    },
    "rir": {
        "sources": {
            "apnic": "https://ftp.apnic.net/stats/apnic/delegated-apnic-extended-latest",
            "ripe": "https://ftp.ripe.net/pub/stats/ripencc/delegated-ripencc-extended-latest",
            "arin": "https://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest",
            "lacnic": "https://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-extended-latest",
            "afrinic": "https://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-extended-latest",
        },
        "countries": [],
        "min_prefix": 8,
        "max_prefix": 24,
        "split_to": 24,
    },
    "webhook": {
        "enabled": True,
        "type": "discord",
        "url": "",
    },
    # Upload output/live.txt lên GoFile + gửi link webhook định kỳ
    "upload": {
        "enabled": True,
        "interval": 15 * 60,   # giây — 15 phút
        "only_changed": False,  # True = bỏ lượt nếu live.txt không đổi
    },
}


def deep_merge(base, override):
    for key, value in (override or {}).items():
        if value and isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def read_extra_targets(cfg):
    """Đọc config/targets_extra.txt — hotspot CIDR ưu tiên quét trước RIR.

    Mỗi dòng: "CIDR" hoặc "CIDR|EXTRA|COUNTRY"; dòng comment "#..." bị bỏ.
    CIDR không hợp lệ bị loại (có cảnh báo), không làm chết pipeline.
    """
    path = cfg["paths"].get("targets_extra")
    if not path or not os.path.exists(path):
        return []
    extra = []
    for line in file_io.read_lines(path):
        parts = [p.strip() for p in line.split("|")]
        cidr = parts[0]
        try:
            ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            warn(f"Bỏ qua CIDR không hợp lệ trong {path}: {cidr}")
            continue
        country = parts[2].upper() if len(parts) > 2 and parts[2] else "XX"
        extra.append((cidr, "extra", country))
    if extra:
        info(f"targets_extra: {len(extra)} hotspot CIDR ưu tiên quét trước")
    return extra


def resolve_paths(cfg):
    for key, value in cfg["paths"].items():
        if not os.path.isabs(value):
            cfg["paths"][key] = os.path.join(BASE_DIR, value)
    return cfg


def load_config(path):
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            user_cfg = yaml.safe_load(fh) or {}
        deep_merge(cfg, user_cfg)
    else:
        info(f"Không tìm thấy {path} — dùng cấu hình mặc định")
    return resolve_paths(cfg)


def parse_args():
    ap = argparse.ArgumentParser(description="Sofia Scan — RIR → 4 stage → webhook")
    ap.add_argument("--config", default=os.path.join(BASE_DIR, "config", "config.yaml"))
    ap.add_argument("--countries", help="Lọc quốc gia, ví dụ: VN,TH,ID")
    ap.add_argument("--targets-only", action="store_true",
                    help="Chỉ sinh targets.txt từ RIR rồi thoát")
    ap.add_argument("--no-resume", action="store_true",
                    help="Quét lại cả các CIDR đã hoàn tất")
    ap.add_argument("--rate", type=int, help="Ghi đè rate của masscan/zmap")
    ap.add_argument("--threads", type=int, help="Ghi đè số thread")
    ap.add_argument("--engine", choices=["masscan", "zmap", "auto"],
                    help="Engine stage 1: masscan | zmap | auto (mặc định: config)")
    ap.add_argument("--generate-ipv4", action="store_true",
                    help="Tự sinh dải IPv4 (scanner.generate_ipv4) thay vì RIR")
    ap.add_argument("--gen-cidr", default="",
                    help="Dải gốc cho --generate-ipv4, ví dụ 0.0.0.0/0 (mặc định)")
    ap.add_argument("--split-to", type=int,
                    help="Chia chunk /N cho --generate-ipv4 (mặc định 16)")
    ap.add_argument("--max-chunks", type=int,
                    help="Giới hạn số chunk cho --generate-ipv4 (0 = tất cả, test nhanh)")
    return ap.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    if args.rate:
        cfg["rate"] = args.rate
    if args.threads:
        cfg["threads"] = args.threads
    if args.engine:
        cfg.setdefault("scanner", {})["engine"] = args.engine
    if args.countries:
        cfg["rir"]["countries"] = [c.strip().upper() for c in args.countries.split(",") if c.strip()]
    if args.generate_ipv4:
        cfg.setdefault("scanner", {}).setdefault("generate_ipv4", {})["enabled"] = True
    gen = cfg.get("scanner", {}).get("generate_ipv4", {})
    if args.gen_cidr:
        gen["cidr"] = args.gen_cidr
    if args.split_to:
        gen["split_to"] = args.split_to
    if args.max_chunks is not None:
        gen["max_chunks"] = args.max_chunks

    output_dir = cfg["paths"]["output_dir"]
    os.makedirs(output_dir, exist_ok=True)
    log_cfg = cfg.get("log") or {}
    setup_file_logging(
        os.path.join(output_dir, "sofia.log"),
        max_bytes=log_cfg.get("max_bytes", 10 * 1024 * 1024),
        backup_count=log_cfg.get("backups", 2),
    )

    info("Sofia Scan khởi động")
    upload_live.start_daemon(cfg)  # background: GoFile upload mỗi interval → webhook
    if gen.get("enabled"):
        count, targets = ipgen.build_targets(cfg)
        success(f"Tự sinh {count} chunk IPv4 ({gen.get('cidr')} → /{gen.get('split_to')})"
                f" → {cfg['paths']['targets']} — quét cổng {cfg.get('scanner', {}).get('ports', '80,443,8080')}")
    else:
        count, targets = rir.build_targets(cfg)
        success(f"Sinh {count} CIDR sau khi lọc exclude → {cfg['paths']['targets']}")

    # Hotspot: config/targets_extra.txt được đẩy lên đầu hàng đợi quét
    extra = read_extra_targets(cfg)
    if extra:
        targets = itertools.chain(extra, targets)
        count += len(extra)
        info(f"Tổng {count} mục tiêu ({len(extra)} hotspot + phần còn lại)")

    if args.targets_only:
        info("--targets-only: thoát trước khi quét")
        return

    Pipeline(cfg).run(targets, resume=not args.no_resume, total=count)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        error("Dừng bởi người dùng (Ctrl+C)")







