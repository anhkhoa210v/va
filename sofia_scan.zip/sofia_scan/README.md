# Sofia Scan

QuétMagento hàng loạt theo dải IP tự sinh từ **5 RIR** (APNIC, RIPE, ARIN, LACNIC, AFRINIC),
chạy **4 stage** theo từng CIDR và thông báo qua **webhook**.

```
main.py ─▶ utils/rir.py ─▶ targets.txt (CIDR|rir|quốc_gia)
        └▶ config/targets_extra.txt  hotspot CIDR ưu tiên quét TRƯỚC RIR
        └▶ core/pipeline.py — với MỖI CIDR:
             webhook "🔎 Đang Quét <CIDR> (<quốc gia>)"
             STAGE 1  scanner.py      masscan|-iL|-p80,443,8080|-oL  → output/live.txt
             (engine stage 1: masscan | zmap | auto — xem `scanner.engine`)
             STAGE 2a fingerprint.py  probe đa endpoint + điểm tin cậy → output/magento.txt
                 /rest/V1/ /graphql /static/version/ /magento_version (+httpx tech-detect)
                 ngưỡng fingerprint.min_score (mặc định 3), debug ra work/<slug>/magento_scored.txt
             STAGE 2b versioning.py   /magento_version → /static/version/ JSON → magento_versions.txt
             STAGE 3  cve_scan.py     offline version→CVE (cves/version_map.yaml)
                                      + nuclei template local (-t) + community (-id) → output/vuln.txt
             STAGE 4  resolver.py     dig PTR + openssl SAN/CN   → output/t.txt
             finally: webhook "✅ Đã Ghi Vào File t.txt <N> domain — dải ... hoàn tất"
```

## Cài đặt

```bash
pip install -r requirements.txt
pip install pytest          # chỉ để chạy tests

# binary ngoài (nếu thiếu):
#   masscan, zmap, httpx (projectdiscovery), nuclei (projectdiscovery), dig (bind9-dnsutils), openssl
sudo apt install masscan zmap bind9-dnsutils openssl
```

## Sử dụng

```bash
# Sinh targets.txt từ tất cả RIR, lọc exclude, rồi quét toàn bộ
sudo python3 main.py

# Chỉ sinh targets.txt (lọc Việt Nam + Thái Lan) rồi thoát
python3 main.py --countries VN,TH --targets-only

# Ghi đè rate/thread, tắt resume
sudo python3 main.py --rate 20000 --threads 100 --no-resume

# Bắt buộc dùng zmap cho stage 1 (mặc định auto: masscan nếu có, ngược lại zmap)
sudo python3 main.py --countries SG --engine zmap

# Tự sinh IPv4 — quét toàn bộ internet bằng zmap (80/443/8080), không cần RIR
sudo python3 main.py --generate-ipv4 --engine zmap
# Thử nhanh: chỉ 2 chunk /24 trong 1.0.0.0/8, không quét thật
python3 main.py --generate-ipv4 --gen-cidr 1.0.0.0/8 --split-to 24 --max-chunks 2 --targets-only
```

> `masscan` cần quyền root (`sudo`). Stage fingerprint/versioning chạy bằng Python threads.

## Cấu hình — `config/config.yaml`

| Khóa | Ý nghĩa |
|---|---|
| `scanner.engine` | engine stage 1: `masscan` / `zmap` / `auto` (auto = masscan nếu có, ngược lại zmap) |
| `scanner.ports` | danh sách cổng quét, ví dụ `80,443,8080` |
| `scanner.masscan.rate` / `.wait` | tốc độ masscan (gói/giây) / giây chờ sau khi quét |
| `scanner.zmap.rate` / `.bandwidth` | tốc độ zmap (gói/giây) / bandwidth ví dụ `100M` (ghi đè rate) |
| `scanner.zmap.cooldown` | giây chờ gói trả về sau khi zmap scan xong |
| `scanner.zmap.seed` | seed ngẫu nhiên hóa thứ tự quét (0 = ngẫu nhiên) |
| `scanner.zmap.source_port` | source port (ví dụ `40000` hoặc `40000-41000`) |
| `scanner.zmap.exclude_file` | file CIDR loại trừ tùy chọn cho zmap |
| `scanner.zmap.quiet` | tắt status updates của zmap |
| `scanner.zmap.dryrun` | `true` = chỉ validate config, không gửi gói (test) — zmap 2.x có bug assertion khi dryrun với CIDR >1 IP, chỉ dùng cho 1 IP |
| `scanner.generate_ipv4.enabled` | `true` = tự sinh chunk IPv4 từ `cidr`, bỏ qua RIR (không cần targets.txt) |
| `scanner.generate_ipv4.cidr` | dải gốc, mặc định `0.0.0.0/0` (toàn bộ IPv4) |
| `scanner.generate_ipv4.split_to` | chia thành chunk /N, mặc định 16 → 65.536 chunk |
| `scanner.generate_ipv4.shuffle` / `.seed` | xáo thứ tự chunk / seed tái lập thứ tự |
| `scanner.generate_ipv4.max_chunks` | `0` = tất cả; `>0` = giới hạn số chunk (test) |
| `scanner.ports` | cổng quét (mặc định `80,443,8080`) — dùng chung cho tự sinh |
| `rate` | tốc độ quét (gói/giây) — fallback khi `scanner.*.rate` trống |
| `threads` | số thread fingerprint/versioning |
| `timeout` | timeout HTTP |
| `cves` | danh sách CVE có template local trong `cves/` (đưa vào nuclei `-t`) |
| `fingerprint.endpoints` | endpoint probe thêm ngoài trang chủ (mặc định `/rest/V1/`, `/graphql`, `/static/version/`, `/magento_version`) |
| `fingerprint.min_score` | ngưỡng điểm tin cậy để kết luận Magento (mặc định 3) |
| `cve.version_map` | `cves/version_map.yaml` — khớp version (stage 2b) → CVE offline, không cần nuclei |
| `cve.community_ids` | CVE chạy qua nuclei `-id` từ nuclei-templates cộng đồng (cần đã cài templates) |
| `paths.targets_extra` | `config/targets_extra.txt` — hotspot CIDR ưu tiên quét trước RIR (mỗi dòng `CIDR` hoặc `CIDR|EXTRA|COUNTRY`) |
| `rir.countries` | rỗng = mọi quốc gia; ví dụ `[VN, TH]` |
| `rir.min_prefix` / `max_prefix` | giới hạn prefix CIDR được chấp nhận |
| `rir.split_to` | chia allocation lớn xuống /N (mặc định 24) |
| `webhook.enabled/type/url` | bật webhook `discord` / `slack` / `generic` |

Dải loại trừ (gov/mil/CDN...) khai báo trong `config/exclude.txt` (một CIDR mỗi dòng).

## Resume

Mỗi CIDR hoàn tất tạo marker `output/work/<slug>/.complete`.
Chạy lại `main.py` sẽ **bỏ qua** các CIDR đó; dùng `--no-resume` để quét lại từ đầu.

## Phát hiện CVE — 2 lớp

1. **Offline (version match)** — không cần nuclei, không gửi thêm request:
   version lấy từ stage 2b khớp `cves/version_map.yaml` → ghi `[version] <url> <ver> — khả năng <CVE>`
   vào `output/vuln.txt` và `output/work/<slug>/cve_version.txt`.
2. **Online (nuclei)** — trên toàn bộ URL Magento:
   - template local: `cves/<CVE>.yaml` qua `-t` (đặt tên file trùng CVE trong `cves:`);
   - template cộng đồng: `cve.community_ids` qua `-id` (cần `nuclei-templates` đã cài:
     `nuclei -update-templates`). Kèm `-retries 2 -fr` giảm false positive.

CVE có template local hiện tại: `cves/CVE-2022-24086.yaml`, `cves/CVE-2024-34102.yaml`,
`cves/CVE-2025-54236.yaml` (nhận diện Magento, version thủ công). Nếu nuclei không tìm thấy
template community cho CVE nào thì chỉ cần chạy `nuclei -update-templates`.

## Nâng tỉ lệ tìm Magento

- **Hotspot**: điền dải hosting/cloud hay dựng Magento vào `config/targets_extra.txt`
  (`CIDR|EXTRA|COUNTRY`), chúng được quét trước toàn bộ RIR.
- **Tăng nhận diện**: probe đa endpoint nên bắt được cả site đổi theme nhưng còn REST/GraphQL;
  muốn an toàn hơn tăng `fingerprint.min_score`, muốn nhạy hơn giảm còn 2 (kèm false positive).
- **Tăng trúng CVE**: `cve.version_map` tận dụng cả version không cần nuclei; thêm CVE mới vào
  `cve.community_ids` + kéo template bằng `nuclei -update-templates`.

## Tests

```bash
cd sofia_scan && python3 -m pytest tests/ -v
```

Phủ: parse/delegated → CIDR (`test_rir.py`), format tin nhắn webhook (`test_webhook.py`),
signature Magento 1/2 (`test_fingerprint.py`), mock dig + SAN (`test_resolver.py`),
thứ tự stage + webhook trong `finally` + resume (`test_pipeline.py`).







