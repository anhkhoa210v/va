"""Khớp version Magento → CVE offline (không cần nuclei).

Đọc cves/version_map.yaml: mỗi CVE khai "max_vulnerable" — phiên bản cao nhất
còn dính lỗi theo từng dòng release X.Y.Z (pnum tính cả "-pN", thiếu = 0).
"""
import os
import re

import yaml

from utils.logger import warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_MAP_PATH = os.path.join(BASE_DIR, "cves", "version_map.yaml")

# "Magento/2.4.6-p3", "2.4.6", "2.4.6-p3 (2.4.6-p3)" ...
VERSION_RE = re.compile(
    r"(?:Magento/)?\s*v?\s*(\d+)\.(\d+)(?:\.(\d+))?(?:-p(\d+))?", re.I
)


def parse_version(text):
    """text → tuple (major, minor, patch, pnum) hoặc None."""
    if not text:
        return None
    match = VERSION_RE.search(str(text))
    if not match:
        return None
    major, minor, patch, pnum = match.groups()
    return (int(major), int(minor), int(patch or 0), int(pnum or 0))


def match_version(version, max_version):
    """version (tuple) có dính lỗi khi <= max_version (tuple)?

    So theo TỪNG DÒNG release X.Y.Z: chỉ so pnum khi cùng (major, minor, patch).
    "2.4.6-p5 and earlier" nghĩa là dòng 2.4.6 với pnum <= 5, không gom
    chung mọi bản 2.4.x (tránh false positive kiểu 2.4.3 bị khớp nhầm
    sang mức vá của 2.4.8).
    """
    if not version or not max_version:
        return False
    if len(version) < 4 or len(max_version) < 4:
        return False
    if version[0:3] != max_version[0:3]:
        return False
    return version[3] <= max_version[3]


def load_map(path=None):
    """path → {CVE-ID: {"name": str, "max_vulnerable": [tuple, ...]}}."""
    path = path or DEFAULT_MAP_PATH
    if not os.path.exists(path):
        warn(f"[cve_map] không tìm thấy {path} — bỏ khớp version")
        return {}
    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}
    result = {}
    for cve, rule in raw.items():
        if not isinstance(rule, dict):
            continue
        tuples = []
        for text in rule.get("max_vulnerable") or []:
            parsed = parse_version(text)
            if parsed:
                tuples.append(parsed)
            else:
                warn(f"[cve_map] bỏ qua max_vulnerable không hợp lệ {text!r} ({cve})")
        result[cve] = {"name": rule.get("name", ""), "max_vulnerable": tuples}
    return result


def match(version_text, version_map=None, map_path=None):
    """version_text ("Magento/2.4.6-p3") → list CVE-ID khả năng dính lỗi."""
    if version_map is None:
        version_map = load_map(map_path)
    version = parse_version(version_text)
    if not version:
        return []
    hits = []
    for cve, rule in version_map.items():
        if any(match_version(version, maxv) for maxv in rule.get("max_vulnerable", [])):
            hits.append(cve)
    return hits


