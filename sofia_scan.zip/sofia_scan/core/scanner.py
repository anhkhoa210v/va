"""STAGE 1: phát hiện host mở cổng (80/443/8080) — engine masscan hoặc zmap.

Hỗ trợ 2 engine quét port:
  - masscan: 1 lần quét nhiều cổng (-p 80,443,8080) → output -oL
  - zmap   : quét từng cổng (per-port loop — tương thích mọi bản zmap,
             kể cả bản chỉ quét 1 cổng/lần) → output mặc định 1 IP/dòng

Chọn engine theo `scanner.engine` trong config:
  - "masscan" / "zmap": dùng đúng engine (warn nếu thiếu binary → fallback auto)
  - "auto" (mặc định): masscan nếu có binary, ngược lại zmap

zmap cần root (raw socket) như masscan; chạy `sudo python3 main.py`.
"""
import ipaddress
import os
import shutil

from utils import file_io, runner
from utils.logger import info, warn

DEFAULT_PORTS = "80,443,8080"

# Các thư mục binary chuẩn — /usr/sbin (zmap) có thể thiếu trong PATH user
_COMMON_PATHS = ("/usr/bin", "/usr/sbin", "/usr/local/bin",
                 "/usr/local/sbin", "/bin", "/sbin")


def _find(binary):
    """shutil.which + fallback quét thư mục chuẩn (zmap thường ở /usr/sbin)."""
    path = shutil.which(binary)
    if path:
        return path
    for base in _COMMON_PATHS:
        candidate = os.path.join(base, binary)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _is_ipv4(text):
    try:
        return ipaddress.IPv4Address(text.strip()).version == 4
    except ValueError:
        return False


def parse_list_file(path):
    """Parse masscan -oL (list format): 'open tcp <port> <ip> <ts>' → ip:port."""
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open" and parts[1] == "tcp":
                out.append(f"{parts[3]}:{parts[2]}")
    return file_io.dedupe_sort(out)


def parse_zmap_output(path, port):
    """Parse zmap output → list 'ip:port'.

    Hỗ trợ 2 định dạng:
      - mặc định: 1 IP mỗi dòng (output-fields = saddr)
      - CSV: 'ip,port' nếu output-fields gồm saddr,sport
    Bỏ qua comment (dòng bắt đầu bằng #) và dòng trống.
    """
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "," in line:
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2 and _is_ipv4(parts[0]) and parts[1].isdigit():
                    out.append(f"{parts[0]}:{parts[1]}")
            elif _is_ipv4(line):
                out.append(f"{line}:{port}")
    return file_io.dedupe_sort(out)


def _engine_config(cfg):
    """Trả về dict chuẩn hóa của block `scanner` (engine/ports/masscan/zmap)."""
    sc = cfg.get("scanner") or {}
    return {
        "engine": (sc.get("engine") or "auto").lower(),
        "ports": str(sc.get("ports") or DEFAULT_PORTS),
        "masscan": sc.get("masscan") or {},
        "zmap": sc.get("zmap") or {},
    }


def pick_engine(cfg):
    """Chọn engine khả dụng theo config; trả về 'masscan' | 'zmap' | None."""
    sc = _engine_config(cfg)
    engine = sc["engine"]
    if engine in ("masscan", "zmap"):
        if _find(engine):
            return engine
        warn(f"[scanner] engine '{engine}' không có binary — thử 'auto'")
    if _find("masscan"):
        return "masscan"
    if _find("zmap"):
        return "zmap"
    return None


def scan_masscan(cidr, workdir, global_live, cfg):
    """Quét CIDR bằng masscan; trả về list 'ip:port'."""
    targets_file = os.path.join(workdir, "cidr.txt")
    raw = os.path.join(workdir, "masscan.list")
    file_io.atomic_write(targets_file, cidr + "\n")

    sc = _engine_config(cfg)
    mc = sc["masscan"]
    rate = mc.get("rate") or cfg.get("rate", 10000)
    wait = mc.get("wait", 0)
    cmd = [
        "masscan", "-iL", targets_file, "-p", sc["ports"],
        "--rate", str(rate), "--wait", str(wait),
        "-oL", raw,
    ]
    proc = runner.run(cmd, timeout=3600)
    if proc.returncode != 0 and proc.stderr:
        warn(f"[masscan] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")
    return parse_list_file(raw)


# Cache tên flag exclude của zmap (khác nhau giữa các bản)
_ZMAP_EXCLUDE_FLAG = {"flag": None}


def _zmap_exclude_flag():
    """zmap >= 4 dùng --exclude-file; bản cũ dùng --blacklist-file."""
    cached = _ZMAP_EXCLUDE_FLAG["flag"]
    if cached:
        return cached
    flag = "--exclude-file"
    try:
        help_text = runner.run(["zmap", "--help"], timeout=30).stdout or ""
        if flag not in help_text and "--blacklist-file" in help_text:
            flag = "--blacklist-file"
    except Exception:
        pass
    _ZMAP_EXCLUDE_FLAG["flag"] = flag
    return flag


def scan_zmap(cidr, workdir, global_live, cfg):
    """Quét CIDR bằng zmap (từng cổng); trả về list 'ip:port'."""
    targets_file = os.path.join(workdir, "cidr.txt")
    file_io.atomic_write(targets_file, cidr + "\n")

    sc = _engine_config(cfg)
    zm = sc["zmap"]
    rate = zm.get("rate") or cfg.get("rate", 10000)
    ports = [p.strip() for p in sc["ports"].split(",") if p.strip()]

    hosts = []
    for port in ports:
        raw = os.path.join(workdir, f"zmap_p{port}.out")
        # zmap giới hạn dải quét bằng -w/--whitelist-file (không có -iL)
        cmd = ["zmap", "-p", port, "-w", targets_file,
               "--rate", str(rate), "-o", raw]
        if zm.get("bandwidth"):
            cmd += ["--bandwidth", str(zm["bandwidth"])]
        if zm.get("cooldown") is not None:
            cmd += ["--cooldown", str(zm["cooldown"])]
        if zm.get("seed"):
            cmd += ["--seed", str(zm["seed"])]
        if zm.get("source_port"):
            cmd += ["--source-port", str(zm["source_port"])]
        if zm.get("interface"):
            cmd += ["-i", str(zm["interface"])]
        if zm.get("quiet", True):
            cmd += ["--quiet"]
        if zm.get("dryrun"):
            cmd += ["--dryrun"]  # chỉ validate config, không gửi gói
        excl = zm.get("exclude_file") or ""
        if excl and os.path.exists(excl):
            cmd += [_zmap_exclude_flag(), excl]
        extra = zm.get("extra_args") or []
        if extra:
            cmd += [str(a) for a in extra]

        proc = runner.run(cmd, timeout=3600)
        if proc.returncode != 0 and proc.stderr:
            warn(f"[zmap] port {port} exit {proc.returncode}: "
                 f"{proc.stderr.strip()[-300:]}")
        hosts += parse_zmap_output(raw, port)
    return file_io.dedupe_sort(hosts)


def scan(cidr, workdir, global_live, cfg):
    """Quét 1 CIDR bằng engine đã chọn; append vào global_live; trả 'ip:port'."""
    engine = pick_engine(cfg)
    hosts = []
    if engine == "masscan":
        hosts = scan_masscan(cidr, workdir, global_live, cfg)
    elif engine == "zmap":
        hosts = scan_zmap(cidr, workdir, global_live, cfg)
    else:
        warn("[scanner] không tìm thấy masscan/zmap — bỏ qua stage 1")

    file_io.append_lines(global_live, hosts)
    info(f"[{cidr}] stage1 ({engine or 'none'}): {len(hosts)} host mở "
         f"{_engine_config(cfg)['ports']}")
    return hosts





