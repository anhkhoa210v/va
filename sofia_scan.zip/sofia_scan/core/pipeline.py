"""Pipeline: tuần tự 4 stage theo từng CIDR + resume + webhook (batch).

Với MỖI CIDR:
  stage1 scanner → stage2a fingerprint → stage2b versioning
  → stage3 cve_scan → stage4 resolver (đếm domain)
  → webhook.scan_done (buffer, gửi gộp chống spam — xem webhook.py)

CIDR đã có marker .complete trong output/work/<slug>/ sẽ được bỏ qua (resume).
"""
import os

import webhook
from core import cve_scan, fingerprint, resolver, scanner, versioning
from utils import file_io
from utils.logger import error, info, success


class Pipeline:
    def __init__(self, cfg):
        self.cfg = cfg
        self.output_dir = cfg["paths"]["output_dir"]
        self.work_dir = os.path.join(self.output_dir, "work")
        webhook.configure(cfg.get("webhook"))

    def _global(self, name):
        return os.path.join(self.output_dir, name)

    def run(self, targets, resume=True, total=None):
        total_domains = 0
        done = 0
        for cidr, rir, country in targets:
            done += 1
            info(f"=== [{done}/{total if total is not None else '?'}] "
                 f"{cidr} ({rir}, {country}) ===")
            total_domains += self.run_cidr(cidr, rir, country, resume=resume)
        success(f"Hoàn tất {done} CIDR — tổng {total_domains} domain trong t.txt")

    def run_cidr(self, cidr, rir, country, resume=True):
        """Chạy 1 CIDR; trả về số domain ghi vào t.txt cho dải này."""
        workdir = os.path.join(self.work_dir, file_io.slugify(cidr))
        done_marker = os.path.join(workdir, ".complete")
        if resume and os.path.exists(done_marker):
            info(f"[{cidr}] đã hoàn tất trước đó — bỏ qua (resume)")
            return 0
        os.makedirs(workdir, exist_ok=True)

        domains = []
        findings = []
        ok = False
        try:
            hosts = scanner.scan(cidr, workdir, self._global("live.txt"), self.cfg)
            urls = fingerprint.run(hosts, workdir, self._global("magento.txt"), self.cfg)
            versions = versioning.run(urls, workdir, self._global("magento_versions.txt"), self.cfg)
            findings = cve_scan.run(urls, workdir, self._global("vuln.txt"), self.cfg, versions=versions)
            domains = resolver.run(urls, workdir, self._global("t.txt"), self.cfg)
            file_io.append_lines(self._global("t.txt"), domains)
            ok = True
        except Exception as exc:
            error(f"[{cidr}] lỗi trong pipeline: {exc}")
        finally:
            webhook.scan_done(cidr, country, len(domains), n_findings=len(findings))

        if ok:
            file_io.atomic_write(done_marker, "ok\n")
        info(f"[{cidr}] xong — {len(domains)} domain")
        return len(domains)






