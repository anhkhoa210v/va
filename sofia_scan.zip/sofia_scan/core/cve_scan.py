"""STAGE 3: phát hiện CVE Magento — 2 lớp, không phụ thuộc 1 kênh:

  A. OFFLINE (version match): url có version từ stage 2b → khớp
     cves/version_map.yaml → dòng "[version] url ver — khả năng CVE-...".
     Chạy được kể cả khi không có nuclei (không cần gửi request thêm).

  B. ONLINE (nuclei):
     1) template local trong cves/<CVE>.yaml qua -t (cũ, giữ nguyên);
     2) template cộng đồng qua -id (cve.community_ids) khi thư mục cves/
        tồn tại — nuclei tự tìm trong nuclei-templates đã cài.
     Thêm -retries 2 và -fr (giảm false positive do request lỗi).

Kết quả A + B đều append vào output/vuln.txt; riêng A còn ghi
output/work/<slug>/cve_version.txt.
"""
import os
import shutil

from core import cve_map
from utils import file_io, runner
from utils.logger import info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CVE_DIR = os.path.join(BASE_DIR, "cves")


def available_templates(cfg):
    """Trả về list đường dẫn template local tồn tại cho các CVE trong config."""
    out = []
    for cve in cfg.get("cves", []):
        path = os.path.join(CVE_DIR, f"{cve}.yaml")
        if os.path.exists(path):
            out.append(path)
        else:
            warn(f"[nuclei] không tìm thấy template {cve} → {path} (bỏ qua)")
    return out


def community_template_ids(cfg):
    """CVE cộng đồng (cve.community_ids) để chạy qua nuclei -id.

    Chỉ có tác dụng khi nuclei-templates đã cài; gating thêm ở run().
    """
    return [cve for cve in (cfg.get("cve", {}).get("community_ids") or []) if cve]


def version_candidates(urls, versions, cfg):
    """url + version → dòng '[version] url ver — khả năng CVE-...' (offline)."""
    if not versions:
        return []
    map_path = cfg.get("cve", {}).get("version_map")
    if map_path and not os.path.isabs(map_path):
        map_path = os.path.join(BASE_DIR, map_path)
    version_map = cve_map.load_map(map_path)
    lines = []
    for url in urls:
        version = versions.get(url)
        if not version:
            continue
        cves = cve_map.match(version, version_map)
        if cves:
            lines.append(f"[version] {url} {version} — khả năng {', '.join(cves)}")
    return lines


def _run_nuclei(targets_file, out, cmd_extra, cfg):
    """Một lượt nuclei; trả về list finding (đã ghi ra out)."""
    cmd = ["nuclei", "-l", targets_file]
    cmd += cmd_extra
    cmd += [
        "-silent", "-nc", "-no-color", "-o", out,
        "-timeout", str(cfg.get("timeout", 15)),
        "-retries", "2", "-fr",
    ]
    proc = runner.run(cmd, timeout=7200)
    if proc.returncode != 0 and proc.stderr:
        warn(f"[nuclei] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")
    return file_io.read_lines(out) if os.path.exists(out) else []


def run(urls, workdir, global_vuln, cfg, versions=None):
    """urls: list URL Magento → findings (version match + nuclei); append vuln.txt."""
    if not urls:
        return []
    findings = []

    # A) offline version match — chạy trước, có kết quả ngay cả khi thiếu nuclei
    version_lines = version_candidates(urls, versions or {}, cfg)
    if version_lines:
        file_io.append_lines(global_vuln, version_lines)
        file_io.append_lines(os.path.join(workdir, "cve_version.txt"), version_lines)
        findings += version_lines

    # B) nuclei
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy nuclei — giữ nguyên kết quả version match")
        info(f"stage3: {len(findings)} findings offline (không có nuclei)")
        return findings

    targets_file = os.path.join(workdir, "magento.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))

    templates = available_templates(cfg)
    community_ids = community_template_ids(cfg)
    if not templates and not community_ids:
        warn(f"[nuclei] không có template local ({CVE_DIR}) lẫn community id — bỏ qua nuclei")
        if findings:
            info(f"stage3: {len(findings)} findings offline")
        return findings

    # B1) template local cves/<CVE>.yaml qua -t
    if templates:
        out = os.path.join(workdir, "nuclei.txt")
        extra = []
        for template in templates:
            extra += ["-t", template]
        findings += _run_nuclei(targets_file, out, extra, cfg)

    # B2) template cộng đồng qua -id (gating: cần thư mục cves/ tồn tại)
    if community_ids and os.path.isdir(CVE_DIR):
        out = os.path.join(workdir, "nuclei_community.txt")
        extra = ["-id", ",".join(community_ids)]
        findings += _run_nuclei(targets_file, out, extra, cfg)

    findings = file_io.dedupe_sort(findings)
    file_io.append_lines(global_vuln, findings)
    info(f"stage3: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei {max(0, len(findings) - len(version_lines))})")
    return findings
