#!/usr/bin/env python3
"""Upload định kỳ output/live.txt lên GoFile → gửi link về webhook.

Hai cách dùng:
  1. Tích hợp trong main.py (khuyến nghị):
       import upload_live
       upload_live.start_daemon(cfg)   # background thread, mỗi interval giây
     Webhook lấy từ cfg['webhook'] (config.yaml, ghi đè bằng env SOFIA_WEBHOOK_URL).

  2. Chạy riêng: python3 upload_live.py [--once] [--file ...] [--interval ...]
     Webhook đọc trực tiếp từ config/config.yaml.
"""
import argparse
import hashlib
import os
import sys
import threading
import time

import requests
import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from utils.logger import error, info, success, warn

INTERVAL_DEFAULT = 15 * 60  # 15 phút
LIVE_DEFAULT = os.path.join(BASE_DIR, "output", "live.txt")
CONFIG_PATH = os.path.join(BASE_DIR, "config", "config.yaml")


def load_webhook_config():
    """Trả về (url, type) — ưu tiên env SOFIA_WEBHOOK_URL > config.yaml."""
    url, kind = "", "generic"
    try:
        with open(CONFIG_PATH, encoding="utf-8") as fh:
            wh = (yaml.safe_load(fh) or {}).get("webhook") or {}
        kind = wh.get("type", "generic")
        url = wh.get("url") or ""
    except OSError:
        pass
    url = os.environ.get("SOFIA_WEBHOOK_URL") or url
    return url, kind


def gofile_servers():
    r = requests.get("https://api.gofile.io/servers", timeout=30)
    r.raise_for_status()
    data = (r.json() or {}).get("data") or {}
    servers = data.get("servers") or ([{"name": data["server"]}] if data.get("server") else [])
    return [s["name"] if isinstance(s, dict) else str(s) for s in servers]


def gofile_upload(path):
    """Upload anonymous lên GoFile, trả về link downloadPage. Thử lần lượt các server."""
    last_err = None
    for name in gofile_servers():
        try:
            with open(path, "rb") as fh:
                r = requests.post(
                    f"https://{name}.gofile.io/contents/uploadfile",
                    files={"file": fh},
                    timeout=600,
                )
            r.raise_for_status()
            body = r.json() or {}
            if body.get("status") == "ok":
                page = (body.get("data") or {}).get("downloadPage")
                if page:
                    return page
            last_err = RuntimeError(f"GoFile/{name}: phản hồi {body}")
        except requests.RequestException as exc:
            last_err = exc
    raise last_err or RuntimeError("GoFile: không có server khả dụng")


def send_webhook(url, kind, text):
    if kind == "discord":
        payload = {"content": text[:2000], "username": "SofiaScan"}
    else:  # slack | generic
        payload = {"text": text[:39000]}
    r = requests.post(url, json=payload, timeout=15)
    if r.status_code == 429:  # tôn trọng Retry-After (giống webhook.py)
        wait = min(float(r.headers.get("Retry-After", 5) or 5), 60)
        warn(f"webhook 429 — chờ {wait}s rồi thử lại")
        time.sleep(wait)
        r = requests.post(url, json=payload, timeout=15)
    r.raise_for_status()


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n /= 1024.0


def file_lines(path):
    with open(path, "rb") as fh:
        return sum(1 for _ in fh)


def run_once(file_path, url, kind, only_changed, last_hash):
    """Upload 1 lần. Trả về hash mới (hoặc last_hash nếu bỏ lượt). Raise nếu upload lỗi."""
    if not os.path.exists(file_path):
        info("upload_live: chưa có live.txt — bỏ lượt này")
        return last_hash
    if os.path.getsize(file_path) == 0:
        info("upload_live: file rỗng — bỏ lượt này")
        return last_hash

    with open(file_path, "rb") as fh:
        digest = hashlib.sha256(fh.read()).hexdigest()
    if only_changed and digest == last_hash:
        info("upload_live: nội dung không đổi (--only-changed) — bỏ lượt này")
        return last_hash

    lines, size = file_lines(file_path), os.path.getsize(file_path)
    link = gofile_upload(file_path)
    success(f"upload_live: đã upload → {link}")

    if url:
        text = (f"📁 SofiaScan — live.txt\n"
                f"• {lines:,} dòng, {human_size(size)}\n"
                f"• Tải: {link}")
        try:
            send_webhook(url, kind, text)
            success("upload_live: đã gửi link về webhook")
        except Exception as exc:
            error(f"upload_live: gửi webhook lỗi: {exc}")
    else:
        warn("upload_live: chưa cấu hình webhook — xem link ở log")
    return digest


# ─────────────────────────── Daemon cho main.py ──────────────────────

def _worker(file_path, url, kind, only_changed, interval):
    last_hash = None
    state_ok = True  # chống spam: chỉ báo lỗi qua webhook khi chuyển OK → lỗi
    while True:
        try:
            new_hash = run_once(file_path, url, kind, only_changed, last_hash)
            if new_hash:
                last_hash = new_hash
            state_ok = True
        except Exception as exc:
            error(f"upload_live: {exc}")
            if state_ok:
                try:
                    send_webhook(url, kind,
                                 "⚠️ SofiaScan — upload live.txt lên GoFile THẤT BÁI "
                                 "(sẽ thử lại chu kỳ sau)")
                except Exception:
                    pass
            state_ok = False
        time.sleep(interval)


def start_daemon(cfg):
    """Khởi động background thread upload live.txt định kỳ (tích hợp main.py).

    cfg: dict config đã merge (DEFAULT_CONFIG + config.yaml):
      - cfg['webhook']['url'] / ['type']  — SOFIA_WEBHOOK_URL ghi đè
      - cfg['paths']['output_dir']        — nơi chứa live.txt
      - cfg['upload']['enabled'/'interval'/'only_changed']
    Trả về Thread (daemon) hoặc None nếu bị tắt / thiếu webhook.
    """
    upload_cfg = cfg.get("upload") or {}
    if not upload_cfg.get("enabled", True):
        info("upload_live: bị tắt (upload.enabled=false)")
        return None

    wh = cfg.get("webhook") or {}
    url = os.environ.get("SOFIA_WEBHOOK_URL") or wh.get("url") or ""
    kind = wh.get("type", "generic")
    if not url:
        warn("upload_live: chưa có webhook.url trong config — không khởi động uploader")
        return None

    interval = max(60, int(upload_cfg.get("interval", INTERVAL_DEFAULT)))
    only_changed = bool(upload_cfg.get("only_changed", False))
    file_path = os.path.join(cfg["paths"]["output_dir"], "live.txt")

    t = threading.Thread(
        target=_worker, name="upload-live", daemon=True,
        args=(file_path, url, kind, only_changed, interval),
    )
    t.start()
    info(f"upload_live: daemon khởi động — file={file_path}, "
         f"chu kỳ={interval}s, webhook type={kind}")
    return t


# ─────────────────────────── Chạy độc lập (CLI) ──────────────────────

def parse_args():
    ap = argparse.ArgumentParser(description="Upload live.txt lên GoFile định kỳ → webhook")
    ap.add_argument("--file", default=LIVE_DEFAULT, help="đường dẫn live.txt (mặc định output/live.txt)")
    ap.add_argument("--interval", type=int, default=INTERVAL_DEFAULT,
                    help="chu kỳ giây giữa 2 lần upload (mặc định 900 = 15 phút)")
    ap.add_argument("--webhook-url", default="", help="ghi đè URL webhook")
    ap.add_argument("--only-changed", action="store_true",
                    help="chỉ upload khi nội dung file thay đổi")
    ap.add_argument("--once", action="store_true", help="chạy 1 lần rồi thoát")
    return ap.parse_args()


def main():
    args = parse_args()
    url = args.webhook_url
    kind = "generic"
    if not url:
        url, kind = load_webhook_config()
    info(f"upload_live: file={args.file} interval={args.interval}s "
         f"webhook={'bật' if url else 'tắt'} type={kind}")

    last_hash = None
    while True:
        try:
            new_hash = run_once(args.file, url, kind, args.only_changed, last_hash)
            if new_hash:
                last_hash = new_hash
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            error(f"upload_live: {exc}")
        if args.once:
            return 0
        time.sleep(args.interval)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        error("upload_live: dừng bởi người dùng (Ctrl+C)")
        sys.exit(130)
